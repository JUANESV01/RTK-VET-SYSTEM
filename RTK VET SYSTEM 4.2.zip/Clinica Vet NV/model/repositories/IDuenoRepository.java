
package model.repositories;
import java.util.*;
import model.entities.Dueno;
public interface IDuenoRepository {
    Dueno save(Dueno d);
    Optional<Dueno> findById(Long id);
    List<Dueno> listar();
    List<Dueno> buscar(String q);
    void setActivo(Long id, boolean activo);
}
