package model.repositories;

import java.util.*;
import model.entities.Examen;

public interface IExamenRepository {
    Examen save(Examen e);
    Optional<Examen> findById(Long id);
    List<Examen> listar();
    List<Examen> listarPorMascota(Long mascotaId);
}
