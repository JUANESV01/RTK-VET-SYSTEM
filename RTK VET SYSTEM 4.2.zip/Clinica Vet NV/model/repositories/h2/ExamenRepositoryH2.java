package model.repositories.h2;

import model.repositories.IExamenRepository;
import model.entities.Examen;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;

public class ExamenRepositoryH2 implements IExamenRepository {
    public ExamenRepositoryH2(){
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement()){
            st.execute("CREATE TABLE IF NOT EXISTS examen ("+
                       "id BIGINT AUTO_INCREMENT PRIMARY KEY,"+
                       "mascota_id BIGINT NOT NULL,"+
                       "descripcion VARCHAR(1000),"+
                       "fecha DATE,"+
                       "creado_por BIGINT,"+
                       "tipo VARCHAR(50))");
        } catch (SQLException e){ throw new RuntimeException(e); }
    }

    private Examen map(ResultSet rs) throws SQLException {
        Examen e = new Examen();
        e.setId(rs.getLong("id"));
        e.setMascotaId(rs.getLong("mascota_id"));
        e.setDescripcion(rs.getString("descripcion"));
        java.sql.Date d = rs.getDate("fecha"); if (d!=null) e.setFecha(d.toLocalDate());
        long cp = rs.getLong("creado_por"); if (!rs.wasNull()) e.setCreadoPorId(cp);
        e.setTipo(rs.getString("tipo"));
        return e;
    }

    @Override public Examen save(Examen e){
        try (Connection cn = ConnectionFactory.get()){
            if (e.getId()==null){
                try (PreparedStatement ps = cn.prepareStatement("INSERT INTO examen(mascota_id,descripcion,fecha,creado_por,tipo) VALUES (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)){
                    ps.setLong(1, e.getMascotaId());
                    ps.setString(2, e.getDescripcion());
                    if (e.getFecha()==null) ps.setNull(3, Types.DATE); else ps.setDate(3, java.sql.Date.valueOf(e.getFecha()));
                    if (e.getCreadoPorId()==null) ps.setNull(4, Types.BIGINT); else ps.setLong(4, e.getCreadoPorId());
                    ps.setString(5, e.getTipo());
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()){ if (rs.next()) e.setId(rs.getLong(1)); }
                }
            } else {
                try (PreparedStatement ps = cn.prepareStatement("UPDATE examen SET mascota_id=?,descripcion=?,fecha=?,creado_por=?,tipo=? WHERE id=?")){
                    ps.setLong(1, e.getMascotaId()); ps.setString(2, e.getDescripcion());
                    if (e.getFecha()==null) ps.setNull(3, Types.DATE); else ps.setDate(3, java.sql.Date.valueOf(e.getFecha()));
                    if (e.getCreadoPorId()==null) ps.setNull(4, Types.BIGINT); else ps.setLong(4, e.getCreadoPorId());
                    ps.setString(5, e.getTipo()); ps.setLong(6, e.getId()); ps.executeUpdate();
                }
            }
            return e;
        } catch (SQLException ex){ throw new RuntimeException(ex); }
    }

    @Override public Optional<Examen> findById(Long id){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("SELECT * FROM examen WHERE id=?")){
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()){ if (rs.next()) return Optional.of(map(rs)); else return Optional.empty(); }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }

    @Override public List<Examen> listar(){
        List<Examen> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM examen ORDER BY fecha DESC, id DESC")){
            while (rs.next()) out.add(map(rs));
        } catch (SQLException ex){ throw new RuntimeException(ex); }
        return out;
    }

    @Override public List<Examen> listarPorMascota(Long mascotaId){
        List<Examen> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("SELECT * FROM examen WHERE mascota_id=? ORDER BY fecha DESC, id DESC")){
            ps.setLong(1, mascotaId);
            try (ResultSet rs = ps.executeQuery()){ while (rs.next()) out.add(map(rs)); }
        } catch (SQLException ex){ throw new RuntimeException(ex); }
        return out;
    }
}
