
package model.repositories.h2;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import model.entities.Factura;
import model.entities.FacturaItem;
import model.repositories.IFacturacionRepository;

public class FacturacionRepositoryH2 implements IFacturacionRepository {
    public FacturacionRepositoryH2(){
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement()){
            st.execute("CREATE TABLE IF NOT EXISTS factura ("+
                       "id BIGINT AUTO_INCREMENT PRIMARY KEY,"+
                       "fecha DATE NOT NULL,"+
                       "dueno_id BIGINT NOT NULL,"+
                       "estado VARCHAR(20) NOT NULL,"+
                       "forma_pago VARCHAR(20),"+
                       "observaciones VARCHAR(300),"+
                       "total DECIMAL(12,2) NOT NULL)");
            st.execute("CREATE TABLE IF NOT EXISTS factura_item ("+
                       "id BIGINT AUTO_INCREMENT PRIMARY KEY,"+
                       "factura_id BIGINT NOT NULL,"+
                       "descripcion VARCHAR(120) NOT NULL,"+
                       "cantidad INT NOT NULL,"+
                       "precio DECIMAL(12,2) NOT NULL,"+
                       "CONSTRAINT fk_item_factura FOREIGN KEY (factura_id) REFERENCES factura(id))");
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    private Factura mapFactura(ResultSet rs) throws SQLException {
        Factura f = new Factura();
        f.setId(rs.getLong("id")); f.setFecha(rs.getDate("fecha").toLocalDate()); f.setDuenoId(rs.getLong("dueno_id"));
        f.setEstado(rs.getString("estado")); f.setFormaPago(rs.getString("forma_pago")); f.setObservaciones(rs.getString("observaciones"));
        f.setTotal(rs.getBigDecimal("total").doubleValue()); return f;
    }
    @Override public Factura saveFacturaConItems(Factura f, List<FacturaItem> items){
        try (Connection cn = ConnectionFactory.get()){
            cn.setAutoCommit(false);
            try {
                try (PreparedStatement ps = cn.prepareStatement("INSERT INTO factura(fecha,dueno_id,estado,forma_pago,observaciones,total) VALUES (?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)){
                    ps.setDate(1, java.sql.Date.valueOf(f.getFecha()!=null?f.getFecha():LocalDate.now()));
                    ps.setLong(2, f.getDuenoId());
                    ps.setString(3, f.getEstado());
                    ps.setString(4, f.getFormaPago());
                    ps.setString(5, f.getObservaciones());
                    ps.setBigDecimal(6, java.math.BigDecimal.valueOf(f.getTotal()));
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()){ if (rs.next()) f.setId(rs.getLong(1)); }
                }
                try (PreparedStatement ps = cn.prepareStatement("INSERT INTO factura_item(factura_id,descripcion,cantidad,precio) VALUES (?,?,?,?)")){
                    for (var it : items){
                        ps.setLong(1, f.getId()); ps.setString(2, it.getDescripcion()); ps.setInt(3, it.getCantidad()); ps.setBigDecimal(4, java.math.BigDecimal.valueOf(it.getPrecio())); ps.addBatch();
                    }
                    ps.executeBatch();
                }
                cn.commit();
                return f;
            } catch (SQLException e){
                cn.rollback();
                throw e;
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public void actualizarEstado(long id, String estado){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("UPDATE factura SET estado=? WHERE id=?")){
            ps.setString(1, estado); ps.setLong(2, id); ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public void setFormaPago(long id, String formaPago){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("UPDATE factura SET forma_pago=? WHERE id=?")){
            ps.setString(1, formaPago); ps.setLong(2, id); ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public Optional<Factura> findFactura(long id){
        String sql = "SELECT f.*, d.nombre AS dueno_nombre FROM factura f JOIN dueno d ON d.id=f.dueno_id WHERE f.id=?";
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sql)){
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()){
                    Factura f = mapFactura(rs); f.setDuenoNombre(rs.getString("dueno_nombre")); return Optional.of(f);
                } else return Optional.empty();
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public List<Factura> listar(LocalDate desde, LocalDate hasta, String estado, String duenoTexto){
        StringBuilder sb = new StringBuilder("SELECT f.*, d.nombre AS dueno_nombre FROM factura f JOIN dueno d ON d.id=f.dueno_id WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (desde!=null){ sb.append(" AND f.fecha>=?"); params.add(java.sql.Date.valueOf(desde)); }
        if (hasta!=null){ sb.append(" AND f.fecha<=?"); params.add(java.sql.Date.valueOf(hasta)); }
        if (estado!=null && !estado.isBlank()){ sb.append(" AND UPPER(f.estado)=UPPER(?)"); params.add(estado); }
        if (duenoTexto!=null && !duenoTexto.isBlank()){ sb.append(" AND UPPER(d.nombre) LIKE UPPER(?)"); params.add("%"+duenoTexto+"%"); }
        sb.append(" ORDER BY f.fecha DESC, f.id DESC");
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sb.toString())){
            for (int i=0;i<params.size();i++) ps.setObject(i+1, params.get(i));
            List<Factura> out = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    Factura f = mapFactura(rs); f.setDuenoNombre(rs.getString("dueno_nombre")); out.add(f);
                }
            }
            return out;
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public double totalPeriodo(LocalDate desde, LocalDate hasta, String estado){
        StringBuilder sb = new StringBuilder("SELECT COALESCE(SUM(total),0) AS tot FROM factura WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (desde!=null){ sb.append(" AND fecha>=?"); params.add(java.sql.Date.valueOf(desde)); }
        if (hasta!=null){ sb.append(" AND fecha<=?"); params.add(java.sql.Date.valueOf(hasta)); }
        if (estado!=null && !estado.isBlank()){ sb.append(" AND UPPER(estado)=UPPER(?)"); params.add(estado); }
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sb.toString())){
            for (int i=0;i<params.size();i++) ps.setObject(i+1, params.get(i));
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()) return rs.getBigDecimal("tot").doubleValue(); else return 0.0;
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
}
