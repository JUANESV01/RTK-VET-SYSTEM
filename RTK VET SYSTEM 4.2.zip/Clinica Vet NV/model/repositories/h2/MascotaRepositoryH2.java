
package model.repositories.h2;
import model.repositories.IMascotaRepository;
import model.entities.Mascota;
import java.sql.*;
import java.util.*;

public class MascotaRepositoryH2 implements IMascotaRepository {
    public MascotaRepositoryH2(){
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement()){
            st.execute("CREATE TABLE IF NOT EXISTS mascota ("+
                       "id BIGINT AUTO_INCREMENT PRIMARY KEY,"+
                       "nombre VARCHAR(80) NOT NULL,"+
                       "especie VARCHAR(50) NOT NULL,"+
                       "raza VARCHAR(80),"+
                       "sexo VARCHAR(10),"+
                       "edad_anios INT,"+
                       "peso_kg DECIMAL(6,2),"+
                       "vacunas VARCHAR(300),"+
                       "alergias VARCHAR(300),"+
                       "observaciones VARCHAR(500),"+
                       "dueno_id BIGINT NOT NULL,"+
                       "activo BOOLEAN DEFAULT TRUE,"+
                       "CONSTRAINT fk_mascota_dueno FOREIGN KEY (dueno_id) REFERENCES dueno(id))");
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    private Mascota map(ResultSet rs) throws SQLException {
        Mascota m = new Mascota();
        m.setId(rs.getLong("id")); m.setNombre(rs.getString("nombre"));
        m.setEspecie(rs.getString("especie")); m.setRaza(rs.getString("raza"));
        m.setSexo(rs.getString("sexo")); int edad = rs.getInt("edad_anios"); if (!rs.wasNull()) m.setEdadAnios(edad);
        double peso = rs.getDouble("peso_kg"); if (!rs.wasNull()) m.setPesoKg(peso);
        m.setVacunas(rs.getString("vacunas")); m.setAlergias(rs.getString("alergias")); m.setObservaciones(rs.getString("observaciones"));
        m.setDuenoId(rs.getLong("dueno_id")); m.setActivo(rs.getBoolean("activo")); return m;
    }
    @Override public Mascota save(Mascota m){
        try (Connection cn = ConnectionFactory.get()){
            if (m.getId()==null){
                try (PreparedStatement ps = cn.prepareStatement("INSERT INTO mascota(nombre,especie,raza,sexo,edad_anios,peso_kg,vacunas,alergias,observaciones,dueno_id,activo) VALUES (?,?,?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)){
                    ps.setString(1,m.getNombre()); ps.setString(2,m.getEspecie()); ps.setString(3,m.getRaza()); ps.setString(4,m.getSexo());
                    if (m.getEdadAnios()==null) ps.setNull(5, Types.INTEGER); else ps.setInt(5, m.getEdadAnios());
                    if (m.getPesoKg()==null) ps.setNull(6, Types.DECIMAL); else ps.setDouble(6, m.getPesoKg());
                    ps.setString(7,m.getVacunas()); ps.setString(8,m.getAlergias()); ps.setString(9,m.getObservaciones()); ps.setLong(10,m.getDuenoId()); ps.setBoolean(11,m.isActivo());
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()){ if (rs.next()) m.setId(rs.getLong(1)); }
                }
            } else {
                try (PreparedStatement ps = cn.prepareStatement("UPDATE mascota SET nombre=?,especie=?,raza=?,sexo=?,edad_anios=?,peso_kg=?,vacunas=?,alergias=?,observaciones=?,dueno_id=?,activo=? WHERE id=?")){
                    ps.setString(1,m.getNombre()); ps.setString(2,m.getEspecie()); ps.setString(3,m.getRaza()); ps.setString(4,m.getSexo());
                    if (m.getEdadAnios()==null) ps.setNull(5, Types.INTEGER); else ps.setInt(5, m.getEdadAnios());
                    if (m.getPesoKg()==null) ps.setNull(6, Types.DECIMAL); else ps.setDouble(6, m.getPesoKg());
                    ps.setString(7,m.getVacunas()); ps.setString(8,m.getAlergias()); ps.setString(9,m.getObservaciones()); ps.setLong(10,m.getDuenoId()); ps.setBoolean(11,m.isActivo());
                    ps.setLong(12,m.getId()); ps.executeUpdate();
                }
            }
            return m;
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public Optional<Mascota> findById(Long id){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("SELECT * FROM mascota WHERE id=?")){
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()){ if (rs.next()) return Optional.of(map(rs)); else return Optional.empty(); }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public List<Mascota> listar(){
        List<Mascota> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM mascota ORDER BY id DESC")){
            while (rs.next()) out.add(map(rs));
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
    @Override public List<Mascota> buscar(String q){
        List<Mascota> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("SELECT * FROM mascota WHERE UPPER(nombre) LIKE UPPER(?) OR UPPER(especie) LIKE UPPER(?) ORDER BY id DESC")){
            ps.setString(1, "%"+q+"%"); ps.setString(2, "%"+q+"%");
            try (ResultSet rs = ps.executeQuery()){ while (rs.next()) out.add(map(rs)); }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
    @Override public List<Mascota> porDueno(Long duenoId){
        List<Mascota> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("SELECT * FROM mascota WHERE dueno_id=? ORDER BY id DESC")){
            ps.setLong(1, duenoId);
            try (ResultSet rs = ps.executeQuery()){ while (rs.next()) out.add(map(rs)); }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
    @Override public void setActivo(Long id, boolean activo){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("UPDATE mascota SET activo=? WHERE id=?")){
            ps.setBoolean(1, activo); ps.setLong(2, id); ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
}
