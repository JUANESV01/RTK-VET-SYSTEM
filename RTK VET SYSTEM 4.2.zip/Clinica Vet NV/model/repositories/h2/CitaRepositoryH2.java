
package model.repositories.h2;
import model.repositories.ICitaRepository;
import model.entities.Cita;
import java.sql.*;
import java.time.*;
import java.util.*;

public class CitaRepositoryH2 implements ICitaRepository {
    public CitaRepositoryH2(){
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement()){
            st.execute("CREATE TABLE IF NOT EXISTS citas ("+
                       "id BIGINT AUTO_INCREMENT PRIMARY KEY,"+
                       "fecha DATE NOT NULL,"+
                       "hora TIME NOT NULL,"+
                       "minutos INT NOT NULL,"+
                       "medico VARCHAR(100) NOT NULL,"+
                       "mascota_id BIGINT NOT NULL,"+
                       "motivo VARCHAR(300),"+
                       "estado VARCHAR(20) NOT NULL DEFAULT 'CREADA')");
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    private Cita map(ResultSet rs) throws SQLException {
        Cita c = new Cita();
        c.setId(rs.getLong("id")); c.setFecha(rs.getDate("fecha").toLocalDate()); c.setHora(rs.getTime("hora").toLocalTime());
        c.setMinutos(rs.getInt("minutos")); c.setMedico(rs.getString("medico")); c.setMascotaId(rs.getLong("mascota_id")); c.setMotivo(rs.getString("motivo"));
        c.setEstado(rs.getString("estado")); return c;
    }
    @Override public Cita save(Cita c){
        try (Connection cn = ConnectionFactory.get()){
            if (c.getId()==null){
                try (PreparedStatement ps = cn.prepareStatement("INSERT INTO citas(fecha,hora,minutos,medico,mascota_id,motivo,estado) VALUES (?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)){
                    ps.setDate(1, java.sql.Date.valueOf(c.getFecha())); ps.setTime(2, java.sql.Time.valueOf(c.getHora())); ps.setInt(3, c.getMinutos());
                    ps.setString(4, c.getMedico()); ps.setLong(5, c.getMascotaId()); ps.setString(6, c.getMotivo()); ps.setString(7, c.getEstado()); ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()){ if (rs.next()) c.setId(rs.getLong(1)); }
                }
            } else {
                try (PreparedStatement ps = cn.prepareStatement("UPDATE citas SET fecha=?, hora=?, minutos=?, medico=?, mascota_id=?, motivo=?, estado=? WHERE id=?")){
                    ps.setDate(1, java.sql.Date.valueOf(c.getFecha())); ps.setTime(2, java.sql.Time.valueOf(c.getHora())); ps.setInt(3, c.getMinutos());
                    ps.setString(4, c.getMedico()); ps.setLong(5, c.getMascotaId()); ps.setString(6, c.getMotivo()); ps.setString(7, c.getEstado()); ps.setLong(8, c.getId()); ps.executeUpdate();
                }
            }
            return c;
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public Optional<Cita> findById(Long id){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("SELECT * FROM citas WHERE id=?")){
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()){ if (rs.next()) return Optional.of(map(rs)); else return Optional.empty(); }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public void actualizarEstado(Long id, String estado){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("UPDATE citas SET estado=? WHERE id=?")){
            ps.setString(1, estado); ps.setLong(2, id); ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public List<Cita> agendaPorDia(LocalDate fecha, String medico){
        List<Cita> out = new ArrayList<>();
        String sql = "SELECT * FROM citas WHERE fecha=?"+(medico!=null&&!medico.isBlank()?" AND UPPER(medico)=UPPER(?)":"")+" ORDER BY hora";
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sql)){
            ps.setDate(1, java.sql.Date.valueOf(fecha));
            if (sql.contains("UPPER(medico)")) ps.setString(2, medico);
            try (ResultSet rs = ps.executeQuery()){ while (rs.next()) out.add(map(rs)); }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
    @Override public List<Cita> agendaPorSemana(LocalDate lunes, String medico){
        LocalDate hasta = lunes.plusDays(6);
        List<Cita> out = new ArrayList<>();
        String sql = "SELECT * FROM citas WHERE fecha BETWEEN ? AND ?"+(medico!=null&&!medico.isBlank()?" AND UPPER(medico)=UPPER(?)":"")+" ORDER BY fecha,hora";
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sql)){
            ps.setDate(1, java.sql.Date.valueOf(lunes)); ps.setDate(2, java.sql.Date.valueOf(hasta));
            if (sql.contains("UPPER(medico)")) ps.setString(3, medico);
            try (ResultSet rs = ps.executeQuery()){ while (rs.next()) out.add(map(rs)); }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
    @Override public boolean existeSolapamiento(String medico, LocalDate fecha, LocalTime hora, int minutos, Long excludeId){
        // Calcular timestamps de la nueva cita
        java.time.LocalDateTime newStart = fecha.atTime(hora);
        java.time.LocalDateTime newEnd = newStart.plusMinutes(minutos);
        
        // Obtener todas las citas del mismo médico y fecha
        String sql = "SELECT * FROM citas WHERE UPPER(medico)=UPPER(?) AND fecha=?";
        if (excludeId != null) sql += " AND id<>?";
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sql)){
            ps.setString(1, medico); ps.setDate(2, java.sql.Date.valueOf(fecha));
            if (excludeId!=null) { ps.setLong(3, excludeId); }
            try (ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    Cita c = map(rs);
                    java.time.LocalDateTime citaStart = c.getFecha().atTime(c.getHora());
                    java.time.LocalDateTime citaEnd = citaStart.plusMinutes(c.getMinutos());
                    
                    // Verificar solapamiento: las citas se solapan si no están completamente separadas
                    // Solapamiento: newStart < citaEnd AND newEnd > citaStart
                    if (newStart.isBefore(citaEnd) && newEnd.isAfter(citaStart)){
                        return true;
                    }
                }
            }
            return false;
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
}
