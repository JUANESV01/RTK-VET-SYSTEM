
package model.repositories.h2;
import model.repositories.IUsuarioRepository;
import model.entities.Usuario;
import model.entities.Rol;
import java.sql.*;
import java.util.*;

public class UsuarioRepositoryH2 implements IUsuarioRepository {
    public UsuarioRepositoryH2(){
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement()){
            st.execute("CREATE TABLE IF NOT EXISTS usuario ("+
                       "id BIGINT AUTO_INCREMENT PRIMARY KEY,"+
                       "email VARCHAR(120) UNIQUE NOT NULL,"+
                       "nombre VARCHAR(120) NOT NULL,"+
                       "password_hash VARCHAR(200) NOT NULL,"+
                       "rol_id BIGINT NOT NULL,"+
                       "enabled BOOLEAN DEFAULT TRUE,"+
                       "CONSTRAINT fk_usuario_rol FOREIGN KEY (rol_id) REFERENCES rol(id))");
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    private Usuario map(ResultSet rs) throws SQLException {
        Usuario u = new Usuario();
        u.setId(rs.getLong("id"));
        u.setEmail(rs.getString("email"));
        u.setNombre(rs.getString("nombre"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setRol(new Rol(rs.getLong("rol_id"), rs.getString("rol_name")));
        u.setEnabled(rs.getBoolean("enabled"));
        return u;
    }
    @Override public Usuario save(Usuario u){
        try (Connection cn = ConnectionFactory.get()){
            if (u.getId()==null){
                try (PreparedStatement ps = cn.prepareStatement("INSERT INTO usuario(email,nombre,password_hash,rol_id,enabled) VALUES (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)){
                    ps.setString(1, u.getEmail()); ps.setString(2, u.getNombre()); ps.setString(3, u.getPasswordHash());
                    ps.setLong(4, u.getRol().getId()); ps.setBoolean(5, u.isEnabled()); ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()){ if (rs.next()) u.setId(rs.getLong(1)); }
                }
            } else {
                try (PreparedStatement ps = cn.prepareStatement("UPDATE usuario SET email=?, nombre=?, password_hash=?, rol_id=?, enabled=? WHERE id=?")){
                    ps.setString(1, u.getEmail()); ps.setString(2, u.getNombre()); ps.setString(3, u.getPasswordHash());
                    ps.setLong(4, u.getRol().getId()); ps.setBoolean(5, u.isEnabled()); ps.setLong(6, u.getId()); ps.executeUpdate();
                }
            }
            return u;
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public Optional<Usuario> findByEmail(String email){
        String sql = "SELECT u.*, r.name AS rol_name FROM usuario u JOIN rol r ON r.id=u.rol_id WHERE UPPER(u.email)=UPPER(?)";
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sql)){
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()) return Optional.of(map(rs)); else return Optional.empty();
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public Optional<Usuario> findById(Long id){
        String sql = "SELECT u.*, r.name AS rol_name FROM usuario u JOIN rol r ON r.id=u.rol_id WHERE u.id=?";
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sql)){
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()) return Optional.of(map(rs)); else return Optional.empty();
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public List<Usuario> listar(){
        String sql = "SELECT u.*, r.name AS rol_name FROM usuario u JOIN rol r ON r.id=u.rol_id ORDER BY u.id DESC";
        List<Usuario> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sql)){
            try (ResultSet rs = ps.executeQuery()){
                while (rs.next()) out.add(map(rs));
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
    @Override public List<Usuario> buscar(String q){
        String sql = "SELECT u.*, r.name AS rol_name FROM usuario u JOIN rol r ON r.id=u.rol_id WHERE UPPER(u.email) LIKE UPPER(?) OR UPPER(u.nombre) LIKE UPPER(?) ORDER BY u.id DESC";
        List<Usuario> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement(sql)){
            ps.setString(1, "%"+q+"%"); ps.setString(2, "%"+q+"%");
            try (ResultSet rs = ps.executeQuery()){ while (rs.next()) out.add(map(rs)); }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
    @Override public void setEnabled(Long id, boolean enabled){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("UPDATE usuario SET enabled=? WHERE id=?")){
            ps.setBoolean(1, enabled); ps.setLong(2, id); ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public void setPassword(Long id, String newHash){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("UPDATE usuario SET password_hash=? WHERE id=?")){
            ps.setString(1, newHash); ps.setLong(2, id); ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
}
