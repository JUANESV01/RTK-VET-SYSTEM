
package model.repositories.h2;
import java.sql.*;
import java.util.*;
import model.entities.Dueno;
import model.repositories.IDuenoRepository;

public class DuenoRepositoryH2 implements IDuenoRepository {
    public DuenoRepositoryH2(){
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement()){
            st.execute("CREATE TABLE IF NOT EXISTS dueno ("+
                       "id BIGINT AUTO_INCREMENT PRIMARY KEY,"+
                       "nombre VARCHAR(120) NOT NULL,"+
                       "documento VARCHAR(60),"+
                       "email VARCHAR(120),"+
                       "telefono VARCHAR(40),"+
                       "activo BOOLEAN DEFAULT TRUE)");
            // Ensure email column exists for older DBs
            try {
                st.execute("ALTER TABLE dueno ADD COLUMN IF NOT EXISTS email VARCHAR(120)");
            } catch (SQLException ex) {
                // Ignore: some older H2 versions may not support IF NOT EXISTS; safe to ignore
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    private Dueno map(ResultSet rs) throws SQLException {
    Dueno d = new Dueno();
    d.setId(rs.getLong("id")); d.setNombre(rs.getString("nombre"));
    d.setDocumento(rs.getString("documento")); d.setEmail(rs.getString("email")); d.setTelefono(rs.getString("telefono"));
    d.setActivo(rs.getBoolean("activo")); return d;
    }
    @Override public Dueno save(Dueno d){
        try (Connection cn = ConnectionFactory.get()){
            if (d.getId()==null){
                try (PreparedStatement ps = cn.prepareStatement("INSERT INTO dueno(nombre,documento,email,telefono,activo) VALUES (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)){
                    ps.setString(1, d.getNombre()); ps.setString(2, d.getDocumento()); ps.setString(3, d.getEmail()); ps.setString(4, d.getTelefono()); ps.setBoolean(5, d.isActivo()); ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()){ if (rs.next()) d.setId(rs.getLong(1)); }
                }
            } else {
                try (PreparedStatement ps = cn.prepareStatement("UPDATE dueno SET nombre=?, documento=?, email=?, telefono=?, activo=? WHERE id=?")){
                    ps.setString(1, d.getNombre()); ps.setString(2, d.getDocumento()); ps.setString(3, d.getEmail()); ps.setString(4, d.getTelefono()); ps.setBoolean(5, d.isActivo()); ps.setLong(6, d.getId()); ps.executeUpdate();
                }
            }
            return d;
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public Optional<Dueno> findById(Long id){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("SELECT * FROM dueno WHERE id=?")){
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()){ if (rs.next()) return Optional.of(map(rs)); else return Optional.empty(); }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public List<Dueno> listar(){
        List<Dueno> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM dueno ORDER BY id DESC")){
            while (rs.next()) out.add(map(rs));
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
    @Override public List<Dueno> buscar(String q){
        List<Dueno> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("SELECT * FROM dueno WHERE UPPER(nombre) LIKE UPPER(?) OR UPPER(documento) LIKE UPPER(?) OR UPPER(email) LIKE UPPER(?) ORDER BY id DESC")){
            ps.setString(1, "%"+q+"%"); ps.setString(2, "%"+q+"%"); ps.setString(3, "%"+q+"%");
            try (ResultSet rs = ps.executeQuery()){ while (rs.next()) out.add(map(rs)); }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
    @Override public void setActivo(Long id, boolean activo){
        try (Connection cn = ConnectionFactory.get(); PreparedStatement ps = cn.prepareStatement("UPDATE dueno SET activo=? WHERE id=?")){
            ps.setBoolean(1, activo); ps.setLong(2, id); ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
}
