
package model.repositories.h2;
import model.repositories.IRolRepository;
import model.entities.Rol;
import java.sql.*;
import java.util.*;

public class RolRepositoryH2 implements IRolRepository {
    public RolRepositoryH2(){
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement()){
            st.execute("CREATE TABLE IF NOT EXISTS rol (id BIGINT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(40) UNIQUE NOT NULL)");
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public Rol save(Rol r){
        try (Connection cn = ConnectionFactory.get()){
            if (r.getId()==null){
                try (PreparedStatement ps = cn.prepareStatement("INSERT INTO rol(name) VALUES (?)", Statement.RETURN_GENERATED_KEYS)){
                    ps.setString(1, r.getName());
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()){ if (rs.next()) r.setId(rs.getLong(1)); }
                }
            } else {
                try (PreparedStatement ps = cn.prepareStatement("UPDATE rol SET name=? WHERE id=?")){
                    ps.setString(1, r.getName()); ps.setLong(2, r.getId()); ps.executeUpdate();
                }
            }
            return r;
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public Optional<Rol> findByName(String name){
        try (Connection cn = ConnectionFactory.get();
             PreparedStatement ps = cn.prepareStatement("SELECT id,name FROM rol WHERE UPPER(name)=UPPER(?)")){
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()) return Optional.of(new Rol(rs.getLong("id"), rs.getString("name")));
                return Optional.empty();
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    @Override public List<Rol> findAll(){
        List<Rol> out = new ArrayList<>();
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement(); ResultSet rs = st.executeQuery("SELECT id,name FROM rol ORDER BY name")){
            while (rs.next()) out.add(new Rol(rs.getLong("id"), rs.getString("name")));
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
}
