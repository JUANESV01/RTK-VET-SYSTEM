package model.repositories.h2;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;
import model.entities.ValoracionMedica;
import model.repositories.IValoracionMedicaRepository;

public class ValoracionMedicaRepositoryH2 implements IValoracionMedicaRepository {
    
    public ValoracionMedicaRepositoryH2() {
        try (Connection cn = ConnectionFactory.get(); Statement st = cn.createStatement()) {
        st.execute("CREATE TABLE IF NOT EXISTS valoracion_medica (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "cita_id BIGINT NOT NULL," +
            "mascota_id BIGINT NOT NULL," +
            "medico VARCHAR(100) NOT NULL," +
            "fecha TIMESTAMP NOT NULL," +
            "motivo VARCHAR(500)," +
            "sintomas VARCHAR(1000)," +
            "diagnostico VARCHAR(1000)," +
            "tratamiento VARCHAR(1000)," +
            "medicamentos VARCHAR(1000)," +
            "observaciones VARCHAR(1000)," +
            "CONSTRAINT fk_valoracion_cita FOREIGN KEY (cita_id) REFERENCES citas(id)," +
            "CONSTRAINT fk_valoracion_mascota FOREIGN KEY (mascota_id) REFERENCES mascota(id))");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private ValoracionMedica mapValoracion(ResultSet rs) throws SQLException {
        ValoracionMedica v = new ValoracionMedica();
        v.setId(rs.getLong("id"));
        v.setCitaId(rs.getLong("cita_id"));
        v.setMascotaId(rs.getLong("mascota_id"));
        v.setMedico(rs.getString("medico"));
        v.setFecha(rs.getTimestamp("fecha").toLocalDateTime());
        v.setMotivo(rs.getString("motivo"));
        v.setSintomas(rs.getString("sintomas"));
        v.setDiagnostico(rs.getString("diagnostico"));
        v.setTratamiento(rs.getString("tratamiento"));
        v.setMedicamentos(rs.getString("medicamentos"));
        v.setObservaciones(rs.getString("observaciones"));
        return v;
    }

    @Override
    public ValoracionMedica save(ValoracionMedica v) {
        try (Connection cn = ConnectionFactory.get()) {
            if (v.getId() == null) {
                try (PreparedStatement ps = cn.prepareStatement(
                        "INSERT INTO valoracion_medica(cita_id,mascota_id,medico,fecha,motivo,sintomas,diagnostico,tratamiento,medicamentos,observaciones) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setLong(1, v.getCitaId());
                    ps.setLong(2, v.getMascotaId());
                    ps.setString(3, v.getMedico());
                    ps.setTimestamp(4, Timestamp.valueOf(v.getFecha() != null ? v.getFecha() : LocalDateTime.now()));
                    ps.setString(5, v.getMotivo());
                    ps.setString(6, v.getSintomas());
                    ps.setString(7, v.getDiagnostico());
                    ps.setString(8, v.getTratamiento());
                    ps.setString(9, v.getMedicamentos());
                    ps.setString(10, v.getObservaciones());
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) v.setId(rs.getLong(1));
                    }
                }
            } else {
                try (PreparedStatement ps = cn.prepareStatement(
                        "UPDATE valoracion_medica SET motivo=?, sintomas=?, diagnostico=?, tratamiento=?, medicamentos=?, observaciones=? WHERE id=?")) {
                    ps.setString(1, v.getMotivo());
                    ps.setString(2, v.getSintomas());
                    ps.setString(3, v.getDiagnostico());
                    ps.setString(4, v.getTratamiento());
                    ps.setString(5, v.getMedicamentos());
                    ps.setString(6, v.getObservaciones());
                    ps.setLong(7, v.getId());
                    ps.executeUpdate();
                }
            }
            return v;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<ValoracionMedica> findByMascotaId(Long mascotaId) {
        try (Connection cn = ConnectionFactory.get();
             PreparedStatement ps = cn.prepareStatement(
                     "SELECT * FROM valoracion_medica WHERE mascota_id=? ORDER BY fecha DESC")) {
            ps.setLong(1, mascotaId);
            List<ValoracionMedica> valoraciones = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    valoraciones.add(mapValoracion(rs));
                }
            }
            return valoraciones;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<ValoracionMedica> findByCitaId(Long citaId) {
        try (Connection cn = ConnectionFactory.get();
             PreparedStatement ps = cn.prepareStatement(
                     "SELECT * FROM valoracion_medica WHERE cita_id=?")) {
            ps.setLong(1, citaId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapValoracion(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}