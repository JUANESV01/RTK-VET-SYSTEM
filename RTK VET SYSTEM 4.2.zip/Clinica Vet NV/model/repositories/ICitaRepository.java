
package model.repositories;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import model.entities.Cita;
public interface ICitaRepository {
    Cita save(Cita c);
    Optional<Cita> findById(Long id);
    void actualizarEstado(Long id, String estado);
    List<Cita> agendaPorDia(LocalDate fecha, String medico);
    List<Cita> agendaPorSemana(LocalDate lunes, String medico);
    boolean existeSolapamiento(String medico, LocalDate fecha, LocalTime hora, int minutos, Long excludeId);
}
