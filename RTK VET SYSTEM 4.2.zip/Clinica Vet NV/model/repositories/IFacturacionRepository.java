
package model.repositories;
import java.time.LocalDate;
import java.util.*;
import model.entities.Factura;
import model.entities.FacturaItem;
public interface IFacturacionRepository {
    Factura saveFacturaConItems(Factura f, List<FacturaItem> items);
    void actualizarEstado(long id, String estado);
    void setFormaPago(long id, String formaPago);
    Optional<Factura> findFactura(long id);
    List<Factura> listar(LocalDate desde, LocalDate hasta, String estado, String duenoTexto);
    double totalPeriodo(LocalDate desde, LocalDate hasta, String estado);
}
