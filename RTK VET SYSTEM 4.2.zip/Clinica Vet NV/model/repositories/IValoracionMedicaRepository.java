package model.repositories;

import java.util.List;
import java.util.Optional;
import model.entities.ValoracionMedica;

public interface IValoracionMedicaRepository {
    ValoracionMedica save(ValoracionMedica valoracion);
    List<ValoracionMedica> findByMascotaId(Long mascotaId);
    Optional<ValoracionMedica> findByCitaId(Long citaId);
}