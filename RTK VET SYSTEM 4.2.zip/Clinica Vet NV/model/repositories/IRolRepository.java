
package model.repositories;
import java.util.*;
import model.entities.Rol;
public interface IRolRepository {
    Rol save(Rol r);
    Optional<Rol> findByName(String name);
    List<Rol> findAll();
}
