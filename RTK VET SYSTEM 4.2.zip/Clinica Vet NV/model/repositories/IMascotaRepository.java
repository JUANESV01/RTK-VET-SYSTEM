
package model.repositories;
import java.util.*;
import model.entities.Mascota;
public interface IMascotaRepository {
    Mascota save(Mascota m);
    Optional<Mascota> findById(Long id);
    List<Mascota> listar();
    List<Mascota> buscar(String q);
    List<Mascota> porDueno(Long duenoId);
    void setActivo(Long id, boolean activo);
}
