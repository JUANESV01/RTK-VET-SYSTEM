
package model.repositories;
import java.util.*;
import model.entities.Usuario;
public interface IUsuarioRepository {
    Usuario save(Usuario u);
    Optional<Usuario> findByEmail(String email);
    Optional<Usuario> findById(Long id);
    List<Usuario> listar();
    List<Usuario> buscar(String q);
    void setEnabled(Long id, boolean enabled);
    void setPassword(Long id, String newHash);
}
