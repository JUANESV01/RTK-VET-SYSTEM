
package model.services;
import java.util.*;
import model.entities.Rol;
import model.repositories.IRolRepository;
public class RolService {
    private final IRolRepository repo;
    public RolService(IRolRepository repo){ this.repo = repo; }
    public Rol ensure(String name){
        return repo.findByName(name).orElseGet(()-> repo.save(new Rol(null,name)));
    }
    public List<Rol> listar(){ return repo.findAll(); }
}
