
package model.services;
import java.util.*;
import model.entities.Dueno;
import model.repositories.IDuenoRepository;
public class DuenoService {
    private final IDuenoRepository repo;
    public DuenoService(IDuenoRepository repo){ this.repo = repo; }
    public Dueno guardar(Dueno d){ return repo.save(d); }
    public List<Dueno> listar(){ return repo.listar(); }
    public List<Dueno> buscar(String q){ return repo.buscar(q); }
    public void setActivo(Long id, boolean a){ repo.setActivo(id,a); }
}
