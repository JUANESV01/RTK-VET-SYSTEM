
package model.services;
import java.util.*;
import model.entities.Mascota;
import model.repositories.IMascotaRepository;
import model.repositories.IDuenoRepository;
public class MascotaService {
    private final IMascotaRepository repo;
    private final IDuenoRepository duenos;
    public MascotaService(IMascotaRepository repo, IDuenoRepository duenos){ this.repo=repo; this.duenos=duenos; }
    public Mascota guardar(Mascota m){
        if (duenos.findById(m.getDuenoId()).isEmpty()) throw new IllegalArgumentException("Dueño inválido");
        return repo.save(m);
    }
    public List<Mascota> listar(){ return repo.listar(); }
    public List<Mascota> buscar(String q){ return repo.buscar(q); }
    public List<Mascota> porDueno(Long id){ return repo.porDueno(id); }
    public void setActivo(Long id, boolean a){ repo.setActivo(id,a); }
}
