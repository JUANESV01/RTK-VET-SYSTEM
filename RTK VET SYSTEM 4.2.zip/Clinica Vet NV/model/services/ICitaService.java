
package model.services;
import java.time.LocalDate;
import model.entities.Cita;
import model.entities.Mascota;

public interface ICitaService {
    Cita crear(Cita c);
    Cita actualizar(Cita c);
    void confirmar(long id);
    void cancelar(long id);
    void atender(long id);
    java.util.Optional<Cita> porId(long id);
    java.util.Optional<Cita> buscar(Long id);
    java.util.Optional<Mascota> buscarMascota(Long id);
    java.util.List<Cita> agendaDia(LocalDate fecha, String medico);
    java.util.List<Cita> agendaSemana(LocalDate lunes, String medico);
}
