
package model.services;
import java.time.LocalDate;
import java.util.*;
import model.entities.Factura;
import model.entities.FacturaItem;
import model.repositories.IFacturacionRepository;
public class FacturacionService implements IFacturacionService {
    private final IFacturacionRepository repo;
    public FacturacionService(IFacturacionRepository repo){ this.repo = repo; }
    @Override public Factura crearFactura(Factura f, List<FacturaItem> items){
        if (f.getFecha()==null) f.setFecha(LocalDate.now());
        if (items==null || items.isEmpty()) throw new IllegalArgumentException("Debe agregar ítems");
        double total=0; for (var it: items){ if (it.getCantidad()<=0 || it.getPrecio()<0) throw new IllegalArgumentException("Ítem inválido"); total += it.getSubtotal(); }
        f.setTotal(total); if (f.getEstado()==null) f.setEstado("EMITIDA");
        return repo.saveFacturaConItems(f, items);
    }
    @Override public void actualizarEstado(long id, String nuevoEstado){ repo.actualizarEstado(id, nuevoEstado); }
    @Override public Optional<Factura> porId(long id){ return repo.findFactura(id); }
    @Override public List<Factura> listar(LocalDate desde, LocalDate hasta, String estado, String duenoTexto){ return repo.listar(desde,hasta,estado,duenoTexto); }
    @Override public double totalPeriodo(LocalDate desde, LocalDate hasta, String estado){ return repo.totalPeriodo(desde,hasta,estado); }

    @Override public void pagarFactura(long id, String formaPago){
        repo.actualizarEstado(id, "PAGADA");
        repo.setFormaPago(id, formaPago);
    }
}
