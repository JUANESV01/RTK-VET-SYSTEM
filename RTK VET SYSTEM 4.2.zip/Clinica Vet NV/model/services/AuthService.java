
package model.services;
import model.repositories.IUsuarioRepository;
import model.entities.Usuario;
public class AuthService implements IAuthService {
    private final IUsuarioRepository usuarios;
    public AuthService(IUsuarioRepository usuarios){ this.usuarios = usuarios; }
    @Override public Usuario login(String email, String password){
        var u = usuarios.findByEmail(email).orElseThrow(()-> new IllegalArgumentException("Credenciales inválidas"));
        String h = PasswordUtil.hash(password);
        if (!u.getPasswordHash().equals(h) || !u.isEnabled()) throw new IllegalArgumentException("Credenciales inválidas");
        return u;
    }
}
