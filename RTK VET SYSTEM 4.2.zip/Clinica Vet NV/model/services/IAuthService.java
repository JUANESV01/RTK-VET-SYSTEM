
package model.services;
import model.entities.Usuario;
public interface IAuthService {
    Usuario login(String email, String password);
}
