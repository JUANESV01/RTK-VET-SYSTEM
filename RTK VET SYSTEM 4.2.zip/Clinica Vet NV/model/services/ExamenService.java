package model.services;

import java.util.*;
import model.entities.Examen;
import model.entities.Usuario;
import model.repositories.IExamenRepository;
import model.repositories.IMascotaRepository;

public class ExamenService {
    private final IExamenRepository repo;
    private final IMascotaRepository mascRepo;

    public ExamenService(IExamenRepository repo, IMascotaRepository mascRepo){ this.repo = repo; this.mascRepo = mascRepo; }

    public Examen crear(Examen e, Usuario actor){
        // Only Médico or Auxiliar can create exams
        String rol = actor != null && actor.getRol()!=null ? actor.getRol().getName() : "";
        boolean permitido = "Médico".equalsIgnoreCase(rol) || "Auxiliar".equalsIgnoreCase(rol);
        if (!permitido) throw new SecurityException("Solo Médicos o Auxiliares pueden crear exámenes");
        if (e.getMascotaId()==null) throw new IllegalArgumentException("Mascota inválida");
        if (mascRepo.findById(e.getMascotaId()).isEmpty()) throw new IllegalArgumentException("No existe la mascota");
        e.setCreadoPorId(actor != null ? actor.getId() : null);
        if (e.getFecha()==null) e.setFecha(java.time.LocalDate.now());
        if (e.getTipo()==null) e.setTipo("EXAMEN");
        return repo.save(e);
    }

    public List<Examen> listar(){ return repo.listar(); }
    public List<Examen> porMascota(Long id){ return repo.listarPorMascota(id); }
    public Optional<Examen> buscar(Long id){ return repo.findById(id); }
}
