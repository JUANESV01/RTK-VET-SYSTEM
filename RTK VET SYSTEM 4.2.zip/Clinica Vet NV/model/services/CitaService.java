
package model.services;
import java.time.LocalDate;
import java.util.*;
import model.entities.Cita;
import model.entities.Mascota;
import model.repositories.ICitaRepository;
import model.repositories.IMascotaRepository;
import model.services.notify.Notifier;

public class CitaService implements ICitaService {
    private final ICitaRepository repo;
    private final IMascotaRepository mascotas;
    private final Notifier notifier = new Notifier();
    
    public CitaService(ICitaRepository repo, IMascotaRepository mascotas){ 
        this.repo=repo; 
        this.mascotas=mascotas; 
    }
    
    @Override public Cita crear(Cita c){
        if (mascotas.findById(c.getMascotaId()).isEmpty()) throw new IllegalArgumentException("Mascota inválida");
        if (c.getMinutos()<=0) throw new IllegalArgumentException("Duración inválida");
        if (repo.existeSolapamiento(c.getMedico(), c.getFecha(), c.getHora(), c.getMinutos(), c.getId())) throw new IllegalArgumentException("Solapamiento para ese médico");
        return repo.save(c);
    }
    
    @Override public Cita actualizar(Cita c){ return crear(c); }
    
    @Override public void confirmar(long id){ repo.actualizarEstado(id, "CONFIRMADA"); }
    
    @Override public void cancelar(long id){ 
        var c = repo.findById(id).orElseThrow(); 
        repo.actualizarEstado(id, "CANCELADA"); 
        notifier.notifyCancel(c.getFecha(), c.getMedico()); 
    }
    
    @Override public void atender(long id){ repo.actualizarEstado(id, "ATENDIDA"); }
    
    @Override public Optional<Cita> porId(long id){ return repo.findById(id); }
    
    @Override public Optional<Cita> buscar(Long id) { return repo.findById(id); }
    
    @Override public Optional<Mascota> buscarMascota(Long id) { 
        return mascotas.findById(id); 
    }
    
    @Override public List<Cita> agendaDia(LocalDate fecha, String medico){ 
        return repo.agendaPorDia(fecha, medico); 
    }
    
    @Override public List<Cita> agendaSemana(LocalDate lunes, String medico){ 
        return repo.agendaPorSemana(lunes, medico); 
    }
    
    public Notifier notifier(){ return notifier; }
}
