
package model.services;
import java.util.*;
import model.entities.Usuario;
import model.repositories.IUsuarioRepository;
public class UsuarioService {
    private final IUsuarioRepository repo;
    public UsuarioService(IUsuarioRepository repo){ this.repo = repo; }
    public Usuario crear(Usuario u){ return repo.save(u); }
    public void setEnabled(Long id, boolean enabled){ repo.setEnabled(id, enabled); }
    public void resetPass(Long id, String plain){ repo.setPassword(id, PasswordUtil.hash(plain)); }
    public List<Usuario> listar(){ return repo.listar(); }
    public List<Usuario> buscar(String q){ return repo.buscar(q); }


    //nueva mod
    public Usuario buscarPorEmail(String email){
    return repo.findByEmail(email).orElse(null);
}

}



