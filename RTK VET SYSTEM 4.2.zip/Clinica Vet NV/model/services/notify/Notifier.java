
package model.services.notify;
import java.time.LocalDate;
import java.util.*;
public class Notifier implements NotificationSubject {
    private final List<NotificationObserver> obs = new ArrayList<>();
    @Override public void addObserver(NotificationObserver o){ obs.add(o); }
    @Override public void removeObserver(NotificationObserver o){ obs.remove(o); }
    @Override public void notifyCancel(LocalDate fecha, String medico){ for (var o: obs) o.onCitaCancelada(fecha, medico); }
}
