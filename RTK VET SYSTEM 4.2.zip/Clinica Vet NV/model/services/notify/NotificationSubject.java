
package model.services.notify;
import java.time.LocalDate;
public interface NotificationSubject {
    void addObserver(NotificationObserver o);
    void removeObserver(NotificationObserver o);
    void notifyCancel(LocalDate fecha, String medico);
}
