
package model.services.notify;
import java.time.LocalDate;
public interface NotificationObserver {
    void onCitaCancelada(LocalDate fecha, String medico);
}
