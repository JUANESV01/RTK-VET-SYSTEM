package model.services;

import java.util.List;
import java.util.Optional;
import model.entities.ValoracionMedica;
import model.repositories.IValoracionMedicaRepository;

public class ValoracionMedicaService {
    private final IValoracionMedicaRepository repository;

    public ValoracionMedicaService(IValoracionMedicaRepository repository) {
        this.repository = repository;
    }

    public ValoracionMedica guardar(ValoracionMedica valoracion) {
        return repository.save(valoracion);
    }

    public List<ValoracionMedica> obtenerHistorialMedico(Long mascotaId) {
        return repository.findByMascotaId(mascotaId);
    }

    public Optional<ValoracionMedica> buscarPorCita(Long citaId) {
        return repository.findByCitaId(citaId);
    }
}