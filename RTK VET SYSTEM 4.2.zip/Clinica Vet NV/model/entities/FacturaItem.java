
package model.entities;
public class FacturaItem {
    private Long id;
    private Long facturaId;
    private String descripcion;
    private int cantidad;
    private double precio;
    public Long getId(){ return id; } public void setId(Long id){ this.id=id; }
    public Long getFacturaId(){ return facturaId; } public void setFacturaId(Long facturaId){ this.facturaId=facturaId; }
    public String getDescripcion(){ return descripcion; } public void setDescripcion(String d){ this.descripcion=d; }
    public int getCantidad(){ return cantidad; } public void setCantidad(int c){ this.cantidad=c; }
    public double getPrecio(){ return precio; } public void setPrecio(double p){ this.precio=p; }
    public double getSubtotal(){ return cantidad * precio; }
}
