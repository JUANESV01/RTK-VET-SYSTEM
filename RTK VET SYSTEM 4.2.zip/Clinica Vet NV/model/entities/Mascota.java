
package model.entities;
public class Mascota {
    private Long id;
    private String nombre;
    private String especie;
    private String raza;
    private String sexo;
    private Integer edadAnios;
    private Double pesoKg;
    private String vacunas;
    private String alergias;
    private String observaciones;
    private Long duenoId;
    private boolean activo = true;
    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public String getNombre(){ return nombre; }
    public void setNombre(String nombre){ this.nombre=nombre; }
    public String getEspecie(){ return especie; }
    public void setEspecie(String especie){ this.especie=especie; }
    public String getRaza(){ return raza; }
    public void setRaza(String raza){ this.raza=raza; }
    public String getSexo(){ return sexo; }
    public void setSexo(String sexo){ this.sexo=sexo; }
    public Integer getEdadAnios(){ return edadAnios; }
    public void setEdadAnios(Integer edadAnios){ this.edadAnios=edadAnios; }
    public Double getPesoKg(){ return pesoKg; }
    public void setPesoKg(Double pesoKg){ this.pesoKg=pesoKg; }
    public String getVacunas(){ return vacunas; }
    public void setVacunas(String vacunas){ this.vacunas=vacunas; }
    public String getAlergias(){ return alergias; }
    public void setAlergias(String alergias){ this.alergias=alergias; }
    public String getObservaciones(){ return observaciones; }
    public void setObservaciones(String observaciones){ this.observaciones=observaciones; }
    public Long getDuenoId(){ return duenoId; }
    public void setDuenoId(Long duenoId){ this.duenoId=duenoId; }
    public boolean isActivo(){ return activo; }
    public void setActivo(boolean activo){ this.activo=activo; }
}
