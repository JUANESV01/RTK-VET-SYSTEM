
package model.entities;
import java.time.LocalDate;
import java.time.LocalTime;
public class Cita {
    private Long id;
    private LocalDate fecha;
    private LocalTime hora;
    private int minutos;
    private String medico;
    private Long mascotaId;
    private String motivo;
    private String estado = "CREADA"; // CREADA, CONFIRMADA, ATENDIDA, CANCELADA
    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public LocalDate getFecha(){ return fecha; }
    public void setFecha(LocalDate fecha){ this.fecha=fecha; }
    public LocalTime getHora(){ return hora; }
    public void setHora(LocalTime hora){ this.hora=hora; }
    public int getMinutos(){ return minutos; }
    public void setMinutos(int minutos){ this.minutos=minutos; }
    public String getMedico(){ return medico; }
    public void setMedico(String medico){ this.medico=medico; }
    public Long getMascotaId(){ return mascotaId; }
    public void setMascotaId(Long mascotaId){ this.mascotaId=mascotaId; }
    public String getMotivo(){ return motivo; }
    public void setMotivo(String motivo){ this.motivo=motivo; }
    public String getEstado(){ return estado; }
    public void setEstado(String estado){ this.estado=estado; }
}
