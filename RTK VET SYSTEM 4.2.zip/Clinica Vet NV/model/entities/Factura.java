
package model.entities;
import java.time.LocalDate;
public class Factura {
    private Long id;
    private LocalDate fecha;
    private Long duenoId;
    private String duenoNombre; // UI
    private String estado; // EMITIDA, PAGADA, ANULADA
    private String formaPago; // EFECTIVO, TARJETA, TRANSFERENCIA
    private String observaciones;
    private double total;
    public Long getId(){ return id; } public void setId(Long id){ this.id=id; }
    public LocalDate getFecha(){ return fecha; } public void setFecha(LocalDate fecha){ this.fecha=fecha; }
    public Long getDuenoId(){ return duenoId; } public void setDuenoId(Long duenoId){ this.duenoId=duenoId; }
    public String getDuenoNombre(){ return duenoNombre; } public void setDuenoNombre(String n){ this.duenoNombre=n; }
    public String getEstado(){ return estado; } public void setEstado(String e){ this.estado=e; }
    public String getFormaPago(){ return formaPago; } public void setFormaPago(String f){ this.formaPago=f; }
    public String getObservaciones(){ return observaciones; } public void setObservaciones(String o){ this.observaciones=o; }
    public double getTotal(){ return total; } public void setTotal(double t){ this.total=t; }
}
