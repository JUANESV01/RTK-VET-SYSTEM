package app;

import javax.swing.SwingUtilities;
import model.entities.Rol;
import model.entities.Usuario;
import model.repositories.h2.RolRepositoryH2;
import model.repositories.h2.UsuarioRepositoryH2;
import model.services.AuthService;
import model.services.IAuthService;
import model.services.PasswordUtil;
import model.services.RolService;
import model.services.UsuarioService;
import ui.LoginFrame;

public class App {
    public static void main(String[] args) {
        // Repos y servicios
        var rolRepo   = new RolRepositoryH2();
        var usrRepo   = new UsuarioRepositoryH2();
        var roles     = new RolService(rolRepo);
        var usuarios  = new UsuarioService(usrRepo);

        // Asegurar roles
        Rol adminRol    = roles.ensure("Administrador");
        Rol medicoRol   = roles.ensure("Médico");
        Rol auxiliarRol = roles.ensure("Auxiliar");

        // ---- Admin hardcodeado (solo si no existe) ----
        if (usuarios.buscarPorEmail("admin@vet.com") == null) {
            Usuario u = new Usuario();
            u.setEmail("admin@vet.com");
            u.setNombre("Admin");
            u.setPasswordHash(PasswordUtil.hash("admin")); // contraseña: admin
            u.setRol(adminRol);
            u.setEnabled(true);
            usuarios.crear(u);
            System.out.println("Admin creado: admin@vet.com / admin");
        }

        // ---- (Opcional) Médico hardcodeado ----
        if (usuarios.buscarPorEmail("medico@vet.com") == null) {
            Usuario u = new Usuario();
            u.setEmail("medico@vet.com");
            u.setNombre("Medico");
            u.setPasswordHash(PasswordUtil.hash("medico")); // contraseña: medico
            u.setRol(medicoRol);
            u.setEnabled(true);
            usuarios.crear(u);
        }

        // ---- (Opcional) Auxiliar hardcodeado ----
        if (usuarios.buscarPorEmail("aux@vet.com") == null) {
            Usuario u = new Usuario();
            u.setEmail("aux@vet.com");
            u.setNombre("Aux");
            u.setPasswordHash(PasswordUtil.hash("aux")); // contraseña: aux
            u.setRol(auxiliarRol);
            u.setEnabled(true);
            usuarios.crear(u);
        }

        // Autenticación y GUI
        IAuthService auth = new AuthService(usrRepo);
        SwingUtilities.invokeLater(() -> new LoginFrame(auth).setVisible(true));
    }
}
