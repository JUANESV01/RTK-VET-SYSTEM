package ui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import model.entities.Usuario;
import model.repositories.h2.RolRepositoryH2;
import model.repositories.h2.UsuarioRepositoryH2;
import model.services.IAuthService;
import model.services.PasswordUtil;
import model.services.RolService;
import model.services.UsuarioService;
import ui.forms.UsuarioForm;
import ui.utils.RTKColors;
import ui.utils.SessionUtil;
import ui.utils.Theme;

@SuppressWarnings("this-escape")
public class UsuariosFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final Usuario actual;
    private transient final UsuarioService usuarios = new UsuarioService(new UsuarioRepositoryH2());
    private transient final RolService roles = new RolService(new RolRepositoryH2());
    private transient final IAuthService auth;

    private final JTextField txtBuscar = new JTextField(18);
    private final JButton btnBuscar = ui.utils.Theme.createButton("Buscar");
    private final JButton btnNuevo = ui.utils.Theme.createButton("Nuevo");
    private final JButton btnEditar = ui.utils.Theme.createButton("Editar");
    private final JButton btnDesactivar = ui.utils.Theme.createButton("Desactivar");
    private final JButton btnActivar = ui.utils.Theme.createButton("Activar");
    private final JButton btnResetPass = ui.utils.Theme.createButton("Reset pass");

    private final String[] COLS = {"ID","Usuario","Nombre","Rol","Estado"};
    private final DefaultTableModel model = new DefaultTableModel(COLS,0){ @Override public boolean isCellEditable(int r,int c){ return false; }};
    private final JTable tbl = new JTable(model);
    private transient final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);

    public UsuariosFrame(Usuario actual, IAuthService auth){
        super("Usuarios");
        this.actual = actual;
        this.auth = auth;
        if (actual.getRol()==null || !"Administrador".equalsIgnoreCase(actual.getRol().getName())){
            JOptionPane.showMessageDialog(this, "No tienes permiso."); 
            dispose(); 
            return;
        }

        setSize(820, 520); 
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

    JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
    top.add(new JLabel("Buscar:")); 
    top.add(txtBuscar); 
    top.add(btnBuscar);
    var btnCerrarSesion = ui.utils.Theme.createButton("Cerrar sesión");
    top.add(new JLabel("  ")); top.add(btnCerrarSesion);
    btnCerrarSesion.addActionListener(e -> SessionUtil.cerrarSesion(this, auth));

    JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT));
    bar.add(btnNuevo); 
    bar.add(btnEditar); 
    bar.add(btnDesactivar); 
    bar.add(btnActivar); 
    bar.add(btnResetPass);

        tbl.setRowHeight(26); 
        tbl.setAutoCreateRowSorter(true); 
        tbl.setRowSorter(sorter);
        tbl.getTableHeader().setBackground(RTKColors.LIGHT_BLUE); 
        tbl.getTableHeader().setForeground(RTKColors.DARK_GRAY);

    JPanel northContainer = new JPanel(new BorderLayout());
    northContainer.add(ui.utils.Theme.createHeaderPanel("RTK VET - Gestión de Usuarios", actual, () -> SessionUtil.cerrarSesion(UsuariosFrame.this, auth)), BorderLayout.NORTH);
    northContainer.add(top, BorderLayout.SOUTH);
    add(northContainer, BorderLayout.NORTH);
    add(new JScrollPane(tbl), BorderLayout.CENTER); 
    add(bar, BorderLayout.SOUTH);

        btnBuscar.addActionListener(e->refrescar());
        txtBuscar.addActionListener(e->refrescar());
        btnNuevo.addActionListener(e->nuevo());
        btnEditar.addActionListener(e->editar());
        btnDesactivar.addActionListener(e->cambiarEstado(false));
        btnActivar.addActionListener(e->cambiarEstado(true));
        btnResetPass.addActionListener(e->resetPassword());
        tbl.addMouseListener(new java.awt.event.MouseAdapter(){ 
            @Override public void mouseClicked(java.awt.event.MouseEvent e){ 
                if(e.getClickCount()==2 && tbl.getSelectedRow()!=-1) editar(); 
            }
        });

        // Seed mínimo si está vacío
        seedMinimo();

        refrescar();
        Theme.applyToFrame(this);
    }

    private void style(JButton b){ 
        b.setBackground(RTKColors.PRIMARY_BLUE); 
        b.setForeground(Color.WHITE); 
        b.setOpaque(true); 
        b.setFocusPainted(false); 
    }
    private void styleCerrarSesion(JButton b){ 
        b.setBackground(new Color(220, 53, 69)); 
        b.setForeground(Color.WHITE); 
        b.setOpaque(true); 
        b.setFocusPainted(false); 
    }

    private void refrescar(){
        model.setRowCount(0); 
        String q = txtBuscar.getText().trim();
        java.util.List<Usuario> lista = q.isEmpty()? usuarios.listar() : usuarios.buscar(q);
        for (Usuario u: lista){ 
            model.addRow(new Object[]{ 
                u.getId(), 
                u.getEmail(), 
                u.getNombre(), 
                (u.getRol()!=null?u.getRol().getName():""), 
                (u.isEnabled()? "Activo":"Inactivo") 
            }); 
        }
        sorter.setRowFilter(q.isEmpty()? null : RowFilter.regexFilter("(?i)"+q));
    }

    private Long idSel(){ 
        int vr = tbl.getSelectedRow(); 
        if (vr==-1) { 
            JOptionPane.showMessageDialog(this,"Selecciona un usuario."); 
            return null; 
        } 
        int mr=tbl.convertRowIndexToModel(vr); 
        Object v=model.getValueAt(mr,0); 
        return (v==null)?null: Long.valueOf(String.valueOf(v)); 
    }

    private void nuevo(){
        var form = new UsuarioForm(this, null);
        form.setVisible(true);
        if (form.fueGuardado()) {
            try {
                usuarios.crear(form.getUsuario());
                refrescar();
                JOptionPane.showMessageDialog(this, "Usuario creado exitosamente.");
            } catch(Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void editar(){
        Long id = idSel(); 
        if (id==null) return;

        // Obtener el usuario actual desde la lista
        java.util.List<Usuario> all = usuarios.listar();
        Usuario u = null;
        for (Usuario it : all) { if (id.equals(it.getId())) { u = it; break; } }
        if (u==null) {
            JOptionPane.showMessageDialog(this, "Usuario no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        var form = new UsuarioForm(this, u);
        form.setVisible(true);
        if (form.fueGuardado()) {
            try {
                usuarios.crear(form.getUsuario());
                if (form.necesitaResetPassword()) {
                    usuarios.resetPass(u.getId(), form.getNuevaPassword());
                }
                refrescar();
                JOptionPane.showMessageDialog(this, "Usuario actualizado exitosamente.");
            } catch(Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void cambiarEstado(boolean activo){
        Long id = idSel(); 
        if (id==null) return;
        try {
            usuarios.setEnabled(id, activo);
            refrescar();
            JOptionPane.showMessageDialog(this, "Usuario " + (activo ? "activado" : "desactivado") + " exitosamente.");
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void resetPassword(){
        Long id = idSel(); 
        if (id==null) return;
        
        String nuevaPass = JOptionPane.showInputDialog(this, "Nueva contraseña:", "");
        if (nuevaPass == null || nuevaPass.trim().isBlank()) {
            return;
        }
        
        try {
            usuarios.resetPass(id, nuevaPass.trim());
            JOptionPane.showMessageDialog(this, "Contraseña actualizada exitosamente.");
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void seedMinimo(){
        // Asegura roles
        model.entities.Rol rAdmin = roles.ensure("Administrador");
        model.entities.Rol rMed   = roles.ensure("Médico");
        model.entities.Rol rAux   = roles.ensure("Auxiliar");

        if (usuarios.listar().isEmpty()){
            model.entities.Usuario u = new model.entities.Usuario();
            u.setEmail("admin@vet.com"); 
            u.setNombre("Admin"); 
            u.setPasswordHash(PasswordUtil.hash("admin"));
            u.setRol(rAdmin); 
            usuarios.crear(u);

            model.entities.Usuario m = new model.entities.Usuario();
            m.setEmail("medico@vet.com"); 
            m.setNombre("Médico"); 
            m.setPasswordHash(PasswordUtil.hash("medico")); 
            m.setRol(rMed); 
            usuarios.crear(m);

            model.entities.Usuario a = new model.entities.Usuario();
            a.setEmail("aux@vet.com"); 
            a.setNombre("Auxiliar"); 
            a.setPasswordHash(PasswordUtil.hash("aux")); 
            a.setRol(rAux); 
            usuarios.crear(a);
        }
    }
}
