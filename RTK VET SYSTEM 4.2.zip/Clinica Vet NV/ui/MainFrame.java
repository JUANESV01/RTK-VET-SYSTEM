
package ui;
import java.awt.*;
import javax.swing.*;
import model.entities.Usuario;
import model.services.IAuthService;
import ui.utils.RTKColors;
import ui.utils.Theme;

@SuppressWarnings("this-escape")
public class MainFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final Usuario actual;
    private transient final IAuthService auth;

    public MainFrame(Usuario actual, IAuthService auth){
        super("RTK - VET SYSTEM - Sistema Principal");
        this.actual = actual;
        this.auth = auth;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 650); setLocationRelativeTo(null);

    // We'll apply the global theme at the end of the constructor

    // Top header: slim bar with logo and title
    JPanel header = new JPanel(new BorderLayout());
    header.setBackground(RTKColors.PRIMARY_BLUE);
    header.setPreferredSize(new Dimension(getWidth(), 72));
    header.setBorder(BorderFactory.createEmptyBorder(6,12,6,12));

    String logoPath = "C:\\Users\\JuanV\\OneDrive\\Escritorio\\2025\\Investicaión & proyectos personales\\Robotiktronikx\\LOGO-RTK.jpg";
    ImageIcon logo = Theme.loadLogo(logoPath, 96, 56);
    JLabel lblLogo = new JLabel();
    if (logo != null) lblLogo.setIcon(logo);
    lblLogo.setBorder(BorderFactory.createEmptyBorder(0,0,0,12));

    JLabel title = new JLabel("RTK VET SYSTEM");
    title.setForeground(RTKColors.WHITE);
    title.setFont(new Font("Segoe UI", Font.BOLD, 22));

    JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 8));
    left.setOpaque(false);
    left.add(lblLogo); left.add(title);

    // user info at right
    JLabel userLabel = new JLabel("Usuario: " + (actual!=null? actual.getNombre() : ""));
    userLabel.setForeground(RTKColors.WHITE);
    userLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 8));
    right.setOpaque(false);
    right.add(userLabel);

    header.add(left, BorderLayout.WEST);
    header.add(right, BorderLayout.EAST);

    // Center area: tile grid of main actions
    JPanel center = new JPanel(new GridLayout(2, 4, 18, 18));
    center.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
    center.setBackground(RTKColors.WHITE);

        // Actions (arranged right -> left as requested)
        JButton tGestionUsuarios = Theme.createTile("Gestión de usuarios", null);
        tGestionUsuarios.addActionListener(e -> new ui.UsuariosFrame(actual, auth).setVisible(true));

        JButton tDuenos = Theme.createTile("Dueños", null);
        tDuenos.addActionListener(e -> new ui.DuenosFrame(auth).setVisible(true));

        JButton tMascotas = Theme.createTile("Mascotas", null);
        tMascotas.addActionListener(e -> new ui.MascotasFrame(auth, actual).setVisible(true));

        JButton tAgendar = Theme.createTile("Agendar citas / vacunas", null);
        tAgendar.addActionListener(e -> new ui.CitasFrame(actual, auth).setVisible(true));

        JButton tCitas = Theme.createTile("Citas", null);
        tCitas.addActionListener(e -> new ui.CitasFrame(actual, auth).setVisible(true));

    JButton tExamConst = Theme.createTile("Exámenes y Constancias", null);
    tExamConst.addActionListener(e -> new ui.ExamenesConstanciasFrame(actual, auth).setVisible(true));

        JButton tReportes = Theme.createTile("Reportes", null);
        tReportes.addActionListener(e -> new ui.ReportesFrame(auth).setVisible(true));

        JButton tFacturacion = Theme.createTile("Facturación", null);
        tFacturacion.addActionListener(e -> new ui.FacturasFrame(auth, actual).setVisible(true));

        // Add in left-to-right order so that visually it appears right-to-left as requested
        // Top row (left->right): Agendar(4), Mascotas(3), Dueños(2), Gestión usuarios(1)
        center.add(tAgendar); center.add(tMascotas); center.add(tDuenos); center.add(tGestionUsuarios);
        // Bottom row (left->right): Facturación(8), Reportes(7), Exámenes y Constancias(6), Citas(5)
        center.add(tFacturacion); center.add(tReportes); center.add(tExamConst); center.add(tCitas);

    // Layout
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(header, BorderLayout.NORTH);
    getContentPane().add(center, BorderLayout.CENTER);

        // small footer with logout
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.setBackground(RTKColors.WHITE);
        JButton btnSalir = Theme.createButton("Salir");
        btnSalir.addActionListener(e -> cerrarSesion());
        footer.add(btnSalir);
        getContentPane().add(footer, BorderLayout.SOUTH);

        // apply permissions for tiles (enable/disable instead of hide)
        aplicarPermisos(actual, tGestionUsuarios, tFacturacion);

        // Apply global theme (white background) now that UI is built
        Theme.applyToFrame(this);
    }
    
    private void cerrarSesion() {
        int respuesta = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro que desea cerrar sesión?",
            "Cerrar sesión",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (respuesta == JOptionPane.YES_OPTION) {
            // Cerrar todas las ventanas hijas
            Window[] windows = Window.getWindows();
            for (Window window : windows) {
                if (window != this && window instanceof JFrame) {
                    window.dispose();
                }
            }
            
            // Cerrar el MainFrame actual
            dispose();
            
            // Abrir nuevo LoginFrame
            SwingUtilities.invokeLater(() -> {
                LoginFrame loginFrame = new LoginFrame(auth);
                loginFrame.setVisible(true);
            });
        }
    }

    private void aplicarPermisos(Usuario actual, JButton usuariosBtn, JButton facturacionBtn){
        String rol = actual!=null && actual.getRol()!=null? actual.getRol().getName() : "";
        boolean esAdmin = "Administrador".equalsIgnoreCase(rol);
        boolean esAux   = "Auxiliar".equalsIgnoreCase(rol);
        // Usuarios: enable only for Admin, otherwise show disabled with tooltip
        if (usuariosBtn != null) {
            usuariosBtn.setEnabled(esAdmin);
            if (!esAdmin) usuariosBtn.setToolTipText("Requiere rol Administrador");
            else usuariosBtn.setToolTipText(null);
        }
        // Facturación: enable only for Auxiliar
        if (facturacionBtn != null) {
            facturacionBtn.setEnabled(esAux);
            if (!esAux) facturacionBtn.setToolTipText("Requiere rol Auxiliar");
            else facturacionBtn.setToolTipText(null);
        }
    }
}
