
package ui;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import model.repositories.h2.DuenoRepositoryH2;
import model.services.DuenoService;
import model.services.IAuthService;
import ui.forms.DuenoForm;
import ui.utils.RTKColors;
import ui.utils.SessionUtil;
import ui.utils.Theme;

@SuppressWarnings("this-escape")
public class DuenosFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final DuenoService srv = new DuenoService(new DuenoRepositoryH2());
    @SuppressWarnings("unused")
    private transient final IAuthService auth;
    private final JTextField txtBuscar = new JTextField(18);
    private final JButton btnBuscar = ui.utils.Theme.createButton("Buscar"), btnNuevo = ui.utils.Theme.createButton("Nuevo"), btnEditar = ui.utils.Theme.createButton("Editar"), btnInactivar = ui.utils.Theme.createButton("Inactivar"), btnActivar = ui.utils.Theme.createButton("Activar");
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID","Nombre","Documento","Tel","Estado"},0){ @Override public boolean isCellEditable(int r,int c){ return false; }};
    private final JTable tbl = new JTable(model);
    private transient final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);

    public DuenosFrame(IAuthService auth){
        super("RTK - VET SYSTEM - Gestión de Dueños");
        this.auth = auth;
        setSize(820,520); setLocationRelativeTo(null); setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    var top=new JPanel(new FlowLayout(FlowLayout.LEFT)); top.add(new JLabel("Buscar:")); top.add(txtBuscar); top.add(btnBuscar);
    var btnCerrarSesion = ui.utils.Theme.createButton("Cerrar sesión");
    top.add(new JLabel("  ")); top.add(btnCerrarSesion);
    var bar=new JPanel(new FlowLayout(FlowLayout.LEFT)); for (var b:new JButton[]{btnNuevo,btnEditar,btnInactivar,btnActivar}){ bar.add(b); }
        btnCerrarSesion.addActionListener(e -> SessionUtil.cerrarSesion(this, auth));
        tbl.setRowHeight(26); tbl.setAutoCreateRowSorter(true); tbl.setRowSorter(sorter); tbl.getTableHeader().setBackground(RTKColors.LIGHT_BLUE); tbl.getTableHeader().setForeground(RTKColors.DARK_GRAY);
    JPanel northContainer = new JPanel(new BorderLayout());
    northContainer.add(ui.utils.Theme.createHeaderPanel("RTK VET - Gestión de Dueños", null, () -> SessionUtil.cerrarSesion(DuenosFrame.this, auth)), BorderLayout.NORTH);
    northContainer.add(top, BorderLayout.SOUTH);
    add(northContainer, BorderLayout.NORTH);
    add(new JScrollPane(tbl), BorderLayout.CENTER); add(bar, BorderLayout.SOUTH);

        btnBuscar.addActionListener(e->refrescar()); txtBuscar.addActionListener(e->refrescar());
        btnNuevo.addActionListener(e->nuevo()); btnEditar.addActionListener(e->editar()); btnInactivar.addActionListener(e->cambiar(false)); btnActivar.addActionListener(e->cambiar(true));
        refrescar();
        // Apply RTK theme styles
        Theme.applyToFrame(this);
    }
    // Styling delegated to Theme
    private void refrescar(){ model.setRowCount(0); String q=txtBuscar.getText().trim(); var lista=q.isBlank()? srv.listar():srv.buscar(q); for (var d:lista) model.addRow(new Object[]{d.getId(),d.getNombre(),d.getDocumento(),d.getTelefono(), d.isActivo()? "Activo":"Inactivo"}); sorter.setRowFilter(q.isBlank()?null:RowFilter.regexFilter("(?i)"+q)); }
    private Long idSel(){ int vr=tbl.getSelectedRow(); if (vr==-1){ JOptionPane.showMessageDialog(this,"Selecciona un dueño."); return null;} int mr=tbl.convertRowIndexToModel(vr); Object v=model.getValueAt(mr,0); return v==null?null:Long.parseLong(String.valueOf(v)); }
    private void nuevo(){ 
        var form = new DuenoForm(this, null);
        form.setVisible(true);
        if (form.fueGuardado()) {
            try {
                srv.guardar(form.getDueno());
                refrescar();
                JOptionPane.showMessageDialog(this, "Dueño creado exitosamente.");
            } catch(Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    private void editar(){ 
        Long id=idSel(); if(id==null) return; 
        var d = srv.listar().stream().filter(x->x.getId().equals(id)).findFirst().orElse(null); 
        if(d==null) return; 
        var form = new DuenoForm(this, d);
        form.setVisible(true);
        if (form.fueGuardado()) {
            try {
                srv.guardar(form.getDueno());
                refrescar();
                JOptionPane.showMessageDialog(this, "Dueño actualizado exitosamente.");
            } catch(Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    private void cambiar(boolean activo){ 
        Long id=idSel(); if(id==null) return; 
        try {
            srv.setActivo(id, activo); 
            refrescar();
            JOptionPane.showMessageDialog(this, "Dueño " + (activo ? "activado" : "inactivado") + " exitosamente.");
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
