
package ui;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.repositories.h2.ConnectionFactory;
import model.services.IAuthService;
import ui.utils.DateUtil;
import ui.utils.SessionUtil;
import ui.utils.Theme;

@SuppressWarnings("this-escape")
public class ReportesFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final IAuthService auth;
    private final JTextField txtDesde=new JTextField(10), txtHasta=new JTextField(10);
    private final DefaultTableModel mCitas=new DefaultTableModel(new String[]{"Médico","Estado","Cantidad"},0){ @Override public boolean isCellEditable(int r,int c){return false;}};
    private final JTable tblCitas=new JTable(mCitas);
    private final DefaultTableModel mTop=new DefaultTableModel(new String[]{"Especie","Motivo","Cantidad"},0){ @Override public boolean isCellEditable(int r,int c){return false;}};
    private final JTable tblTop=new JTable(mTop);
    private final JLabel lblIngresos=new JLabel("$ 0.00");

    public ReportesFrame(IAuthService auth){
        super("RTK - VET SYSTEM - Reportes");
        this.auth = auth;
        setSize(820,520); setLocationRelativeTo(null); setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    var tabs=new JTabbedPane();
    var filtros=new JPanel(new FlowLayout(FlowLayout.LEFT));
    var btn=ui.utils.Theme.createButton("Actualizar");
        filtros.add(new JLabel("Desde (DD/MM/AAAA):")); filtros.add(txtDesde);
        filtros.add(new JLabel("Hasta:")); filtros.add(txtHasta);
    filtros.add(btn);
    var btnCerrarSesion = ui.utils.Theme.createButton("Cerrar sesión");
    filtros.add(new JLabel("  ")); filtros.add(btnCerrarSesion);
        btn.addActionListener(e->actualizarTodo());
        btnCerrarSesion.addActionListener(e -> SessionUtil.cerrarSesion(this, auth));

        var p1=new JPanel(new BorderLayout()); p1.add(new JScrollPane(tblCitas), BorderLayout.CENTER); tabs.add("Citas por médico/estado", p1);
        var p2=new JPanel(new BorderLayout()); p2.add(new JScrollPane(tblTop), BorderLayout.CENTER); tabs.add("Top motivos por especie", p2);
        var p3=new JPanel(new FlowLayout(FlowLayout.LEFT)); p3.add(new JLabel("Ingresos del período: ")); p3.add(lblIngresos); tabs.add("Ingresos", p3);

        JPanel northContainer = new JPanel(new BorderLayout());
        northContainer.add(ui.utils.Theme.createHeaderPanel("RTK VET - Reportes", null, () -> SessionUtil.cerrarSesion(ReportesFrame.this, auth)), BorderLayout.NORTH);
        northContainer.add(filtros, BorderLayout.SOUTH);
        add(northContainer, BorderLayout.NORTH); add(tabs, BorderLayout.CENTER);
        actualizarTodo();
        Theme.applyToFrame(this);
    }
    // styling delegated to Theme
    private void actualizarTodo(){ LocalDate d=parse(txtDesde.getText().trim()), h=parse(txtHasta.getText().trim()); cargarCitas(d,h); cargarTop(d,h); cargarIngresos(d,h); }
    private void cargarCitas(LocalDate d, LocalDate h){
        mCitas.setRowCount(0);
        String sql="SELECT medico, estado, COUNT(*) cant FROM citas WHERE 1=1";
        java.util.List<Object> params=new java.util.ArrayList<>();
        if(d!=null){ sql+=" AND fecha>=?"; params.add(java.sql.Date.valueOf(d)); }
        if(h!=null){ sql+=" AND fecha<=?"; params.add(java.sql.Date.valueOf(h)); }
        sql+=" GROUP BY medico, estado ORDER BY medico, estado";
        try(Connection cn=ConnectionFactory.get(); PreparedStatement ps=cn.prepareStatement(sql)){
            for(int i=0;i<params.size();i++) ps.setObject(i+1, params.get(i));
            try(ResultSet rs=ps.executeQuery()){ while(rs.next()) mCitas.addRow(new Object[]{ rs.getString("medico"), rs.getString("estado"), rs.getInt("cant") }); }
        }catch(Exception ex){ JOptionPane.showMessageDialog(this, ex.getMessage()); }
    }
    private void cargarTop(LocalDate d, LocalDate h){
        mTop.setRowCount(0);
        String sql="SELECT m.especie, c.motivo, COUNT(*) cant FROM citas c JOIN mascota m ON m.id=c.mascota_id WHERE 1=1";
        java.util.List<Object> params=new java.util.ArrayList<>();
        if(d!=null){ sql+=" AND c.fecha>=?"; params.add(java.sql.Date.valueOf(d)); }
        if(h!=null){ sql+=" AND c.fecha<=?"; params.add(java.sql.Date.valueOf(h)); }
        sql+=" GROUP BY m.especie, c.motivo ORDER BY cant DESC LIMIT 20";
        try(Connection cn=ConnectionFactory.get(); PreparedStatement ps=cn.prepareStatement(sql)){
            for(int i=0;i<params.size();i++) ps.setObject(i+1, params.get(i));
            try(ResultSet rs=ps.executeQuery()){ while(rs.next()) mTop.addRow(new Object[]{ rs.getString("especie"), rs.getString("motivo"), rs.getInt("cant") }); }
        }catch(Exception ex){ JOptionPane.showMessageDialog(this, ex.getMessage()); }
    }
    private void cargarIngresos(LocalDate d, LocalDate h){
        String sql="SELECT COALESCE(SUM(total),0) tot FROM factura WHERE 1=1";
        java.util.List<Object> params=new java.util.ArrayList<>();
        if(d!=null){ sql+=" AND fecha>=?"; params.add(java.sql.Date.valueOf(d)); }
        if(h!=null){ sql+=" AND fecha<=?"; params.add(java.sql.Date.valueOf(h)); }
        try(Connection cn=ConnectionFactory.get(); PreparedStatement ps=cn.prepareStatement(sql)){
            for(int i=0;i<params.size();i++) ps.setObject(i+1, params.get(i));
            try(ResultSet rs=ps.executeQuery()){ if(rs.next()) lblIngresos.setText(String.format("$ %.2f", rs.getBigDecimal("tot").doubleValue())); }
        }catch(Exception ex){ JOptionPane.showMessageDialog(this, ex.getMessage()); }
    }
    private static LocalDate parse(String s){ return DateUtil.parse(s); }
}
