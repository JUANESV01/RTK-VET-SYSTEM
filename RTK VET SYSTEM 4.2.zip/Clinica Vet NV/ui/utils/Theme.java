package ui.utils;

import java.awt.*;
import java.net.URL;
import javax.swing.*;

/**
 * Small theme helper for RTK VET System.
 * Provides methods to style frames and create themed buttons.
 */
public final class Theme {
    private Theme() {}

    public static void applyToFrame(JFrame frame) {
        if (frame == null) return;
        // Use a clean white background for content; keep accents in components
        frame.getContentPane().setBackground(RTKColors.WHITE);
        // set a friendly default font for the frame root only
        Font base = new Font("Segoe UI", Font.PLAIN, 12);
        frame.setFont(base);
    }

    /** Apply theme to any Window (JDialog, JFrame, etc.) */
    public static void applyToWindow(Window w) {
        if (w == null) return;
        if (w instanceof JFrame) {
            applyToFrame((JFrame) w);
            return;
        }
        // For dialogs and other windows, set background and font where possible
        try {
            if (w.getOwner() instanceof JFrame) {
                // keep consistency with frame styling
            }
        } catch (Exception ignore) {}
        // try to set background for root pane if present
        try {
            if (w instanceof java.awt.Container) {
                for (Component c : ((java.awt.Container) w).getComponents()) {
                    c.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                }
            }
        } catch (Exception ignore) {}
    }

    /**
     * Create a header panel with RTK logo, title and a user label. Caller should wire a logout action
     * by providing a Runnable that will be executed when the "Cerrar sesión" button is pressed.
     */
    public static JPanel createHeaderPanel(String titleText, model.entities.Usuario user, Runnable logoutAction) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(RTKColors.PRIMARY_BLUE);
        header.setPreferredSize(new Dimension(800, 72));
        header.setBorder(BorderFactory.createEmptyBorder(6,12,6,12));

        ImageIcon logo = loadLogo("C:\\Users\\JuanV\\OneDrive\\Escritorio\\2025\\Investicaión & proyectos personales\\Robotiktronikx\\LOGO-RTK.jpg", 96, 56);
        JLabel lblLogo = new JLabel(); if (logo != null) lblLogo.setIcon(logo);
        lblLogo.setBorder(BorderFactory.createEmptyBorder(0,0,0,12));

        JLabel title = new JLabel(titleText);
        title.setForeground(RTKColors.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 8));
        left.setOpaque(false);
        left.add(lblLogo); left.add(title);

        JLabel userLabel = new JLabel("Usuario: " + (user != null ? user.getNombre() : ""));
        userLabel.setForeground(RTKColors.WHITE);
        userLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 8));
        right.setOpaque(false);
        right.add(userLabel);

        JButton btnCerrar = createButton("Cerrar sesión");
        btnCerrar.addActionListener(e -> { if (logoutAction != null) logoutAction.run(); });
        right.add(btnCerrar);

        header.add(left, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private static void setDefaultFont(Component comp, Font font) {
        comp.setFont(font);
        if (comp instanceof Container) {
            for (Component c : ((Container) comp).getComponents()) {
                setDefaultFont(c, font);
            }
        }
    }

    public static JButton createButton(String text) {
        JButton b = new JButton(text);
        styleButton(b);
        return b;
    }

    public static JButton createButton(String text, Icon icon) {
        JButton b = new JButton(text, icon);
        styleButton(b);
        return b;
    }

    private static void styleButton(AbstractButton b) {
        b.setBackground(RTKColors.PRIMARY_BLUE);
        b.setForeground(RTKColors.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setMargin(new Insets(8, 12, 8, 12));
    }

    /**
     * Create a tile-style button: white background, blue border and blue text,
     * icon above text and centered. Sized for use in a grid of features.
     */
    public static JButton createTile(String text, Icon icon) {
        JButton b = new JButton(text, icon);
        b.setVerticalTextPosition(SwingConstants.BOTTOM);
        b.setHorizontalTextPosition(SwingConstants.CENTER);
        b.setPreferredSize(new Dimension(180, 110));
        b.setBackground(RTKColors.WHITE);
        b.setForeground(RTKColors.PRIMARY_BLUE);
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(RTKColors.PRIMARY_BLUE, 2),
                BorderFactory.createEmptyBorder(8,8,8,8)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        return b;
    }

    /**
     * Load an image icon from absolute path or resource; returns scaled icon or null.
     */
    public static ImageIcon loadLogo(String path, int width, int height) {
        if (path == null) return null;
        try {
            ImageIcon original = new ImageIcon(path);
            int ow = original.getIconWidth();
            int oh = original.getIconHeight();
            if (ow <= 0 || oh <= 0) return original;
            // preserve aspect ratio and fit inside width x height
            double scale = Math.min((double)width / ow, (double)height / oh);
            int nw = (int)Math.round(ow * scale);
            int nh = (int)Math.round(oh * scale);
            Image img = original.getImage().getScaledInstance(nw, nh, Image.SCALE_SMOOTH);
            return new ImageIcon(img);
        } catch (Exception ex) {
            // try classpath resource
            try {
                URL url = Theme.class.getResource(path);
                if (url != null) {
                    ImageIcon original = new ImageIcon(url);
                    int ow = original.getIconWidth();
                    int oh = original.getIconHeight();
                    if (ow <= 0 || oh <= 0) return original;
                    double scale = Math.min((double)width / ow, (double)height / oh);
                    int nw = (int)Math.round(ow * scale);
                    int nh = (int)Math.round(oh * scale);
                    Image img = original.getImage().getScaledInstance(nw, nh, Image.SCALE_SMOOTH);
                    return new ImageIcon(img);
                }
            } catch (Exception ignore) {}
        }
        return null;
    }
}
