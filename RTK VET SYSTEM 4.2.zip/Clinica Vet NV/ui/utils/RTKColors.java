
package ui.utils;

import java.awt.Color;

public class RTKColors {
    public static final Color PRIMARY_BLUE   = new Color(0, 122, 204);
    public static final Color PRIMARY_ORANGE = new Color(255, 140, 0);
    public static final Color LIGHT_BLUE     = new Color(173, 216, 230);
    public static final Color LIGHT_ORANGE   = new Color(255, 218, 185);
    public static final Color WHITE          = Color.WHITE;
    public static final Color DARK_GRAY      = new Color(51, 51, 51);
    // Colores del logo RTK
    public static final Color LOGO_BRIGHT_BLUE = new Color(64, 224, 255);  // Azul brillante/cyan vibrante
    public static final Color LOGO_BRIGHT_ORANGE = new Color(255, 165, 0);  // Naranja brillante
}
