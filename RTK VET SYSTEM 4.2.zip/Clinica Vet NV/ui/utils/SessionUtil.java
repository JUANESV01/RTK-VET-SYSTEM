package ui.utils;

import javax.swing.*;
import java.awt.*;
import model.services.IAuthService;
import ui.LoginFrame;

public class SessionUtil {
    /**
     * Cierra la sesión actual y vuelve al login
     */
    public static void cerrarSesion(JFrame frameActual, IAuthService auth) {
        int respuesta = JOptionPane.showConfirmDialog(
            frameActual,
            "¿Está seguro que desea cerrar sesión?",
            "Cerrar sesión",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (respuesta == JOptionPane.YES_OPTION) {
            // Cerrar todas las ventanas hijas
            Window[] windows = Window.getWindows();
            for (Window window : windows) {
                if (window != frameActual && window instanceof JFrame) {
                    window.dispose();
                }
            }
            
            // Cerrar el frame actual
            frameActual.dispose();
            
            // Abrir nuevo LoginFrame
            SwingUtilities.invokeLater(() -> {
                LoginFrame loginFrame = new LoginFrame(auth);
                loginFrame.setVisible(true);
            });
        }
    }
}

