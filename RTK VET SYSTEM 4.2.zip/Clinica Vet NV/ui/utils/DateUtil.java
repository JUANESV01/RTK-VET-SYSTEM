package ui.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class DateUtil {
    private static final DateTimeFormatter FORMATO_DISPLAY = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter FORMATO_ISO = DateTimeFormatter.ISO_LOCAL_DATE;
    
    /**
     * Formatea una LocalDate a String en formato DD/MM/AAAA
     */
    public static String format(LocalDate date) {
        if (date == null) return "";
        return date.format(FORMATO_DISPLAY);
    }
    
    /**
     * Parsea un String en formato DD/MM/AAAA a LocalDate
     * También acepta formato ISO (YYYY-MM-DD) para compatibilidad
     */
    public static LocalDate parse(String dateStr) {
        if (dateStr == null || dateStr.trim().isBlank()) {
            return null;
        }
        String trimmed = dateStr.trim();
        
        // Limpiar espacios y caracteres extraños
        trimmed = trimmed.replaceAll("\\s+", "");
        
        // Intentar primero con formato DD/MM/AAAA
        try {
            return LocalDate.parse(trimmed, FORMATO_DISPLAY);
        } catch (DateTimeParseException e) {
            // Si falla, intentar con formato ISO (YYYY-MM-DD) para compatibilidad
            try {
                return LocalDate.parse(trimmed, FORMATO_ISO);
            } catch (DateTimeParseException e2) {
                // Intentar con formato DD-MM-AAAA como alternativa
                try {
                    DateTimeFormatter formatoAlternativo = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                    return LocalDate.parse(trimmed, formatoAlternativo);
                } catch (DateTimeParseException e3) {
                    throw new IllegalArgumentException("Formato de fecha inválido. Use DD/MM/AAAA (ejemplo: 25/12/2024). Valor recibido: '" + trimmed + "'");
                }
            }
        }
    }
    
    /**
     * Valida si un String es una fecha válida en formato DD/MM/AAAA
     */
    public static boolean isValid(String dateStr) {
        if (dateStr == null || dateStr.trim().isBlank()) {
            return false;
        }
        try {
            parse(dateStr);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

