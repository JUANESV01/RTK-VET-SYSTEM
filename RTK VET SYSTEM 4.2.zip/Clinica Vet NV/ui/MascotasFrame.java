
package ui;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import model.entities.Mascota;
import model.entities.Usuario;
import model.repositories.h2.DuenoRepositoryH2;
import model.repositories.h2.MascotaRepositoryH2;
import model.services.IAuthService;
import model.services.MascotaService;
import ui.forms.HistorialClinicoForm;
import ui.forms.MascotaForm;
import ui.utils.RTKColors;
import ui.utils.SessionUtil;
import ui.utils.Theme;

@SuppressWarnings("this-escape")
public class MascotasFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final MascotaService srv = new MascotaService(new MascotaRepositoryH2(), new DuenoRepositoryH2());
    private transient final IAuthService auth;
    private transient final Usuario actual;
    private final JTextField txtBuscar = new JTextField(18);
    private final JButton btnBuscar = ui.utils.Theme.createButton("Buscar");
    private final JButton btnNuevo = ui.utils.Theme.createButton("Nuevo");
    private final JButton btnEditar = ui.utils.Theme.createButton("Editar");
    private final JButton btnHistorial = ui.utils.Theme.createButton("Ver Historial Clínico");
    private final JButton btnInactivar = ui.utils.Theme.createButton("Inactivar");
    private final JButton btnActivar = ui.utils.Theme.createButton("Activar");
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID","Nombre","Especie","Raza","DueñoID","Estado"},0){ @Override public boolean isCellEditable(int r,int c){ return false; }};
    private final JTable tbl = new JTable(model);
    private transient final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);

    public MascotasFrame(IAuthService auth, Usuario actual){
        super("RTK - VET SYSTEM - Gestión de Mascotas");
        this.auth = auth;
        this.actual = actual;
        setSize(880,520); setLocationRelativeTo(null); setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    var top=new JPanel(new FlowLayout(FlowLayout.LEFT)); top.add(new JLabel("Buscar:")); top.add(txtBuscar); top.add(btnBuscar);
    var btnCerrarSesion = ui.utils.Theme.createButton("Cerrar sesión");
    top.add(new JLabel("  ")); top.add(btnCerrarSesion);
        var bar=new JPanel(new FlowLayout(FlowLayout.LEFT)); 
        for (var b : new JButton[]{btnNuevo, btnEditar, btnHistorial, btnInactivar, btnActivar}) { 
            bar.add(b); 
        }
        btnCerrarSesion.addActionListener(e -> SessionUtil.cerrarSesion(this, auth));
        tbl.setRowHeight(26); tbl.setAutoCreateRowSorter(true); tbl.setRowSorter(sorter); tbl.getTableHeader().setBackground(RTKColors.LIGHT_BLUE); tbl.getTableHeader().setForeground(RTKColors.DARK_GRAY);
    JPanel northContainer = new JPanel(new BorderLayout());
    northContainer.add(ui.utils.Theme.createHeaderPanel("RTK VET - Gestión de Mascotas", actual, () -> SessionUtil.cerrarSesion(MascotasFrame.this, auth)), BorderLayout.NORTH);
    northContainer.add(top, BorderLayout.SOUTH);
    add(northContainer, BorderLayout.NORTH);
    add(new JScrollPane(tbl), BorderLayout.CENTER); add(bar, BorderLayout.SOUTH);

        btnBuscar.addActionListener(e->refrescar()); 
        txtBuscar.addActionListener(e->refrescar());
        btnNuevo.addActionListener(e->nuevo()); 
        btnEditar.addActionListener(e->editar());
        btnHistorial.addActionListener(e->verHistorial());
        btnInactivar.addActionListener(e->cambiar(false)); 
        btnActivar.addActionListener(e->cambiar(true));
        // Restricción de rol: solo médicos pueden ver historial clínico
        boolean isMedico = actual.getRol() != null && "Médico".equalsIgnoreCase(actual.getRol().getName());
        btnHistorial.setEnabled(isMedico);
        if (!isMedico) {
            btnHistorial.setToolTipText("Solo médicos pueden ver el historial clínico");
        }
        refrescar();
        Theme.applyToFrame(this);
    }
    // Styling delegated to Theme
    private void refrescar(){ model.setRowCount(0); String q=txtBuscar.getText().trim(); var lista=q.isBlank()? srv.listar():srv.buscar(q); for (var m:lista) model.addRow(new Object[]{m.getId(),m.getNombre(),m.getEspecie(),m.getRaza(),m.getDuenoId(), m.isActivo()? "Activo":"Inactivo"}); sorter.setRowFilter(q.isBlank()?null:RowFilter.regexFilter("(?i)"+q)); }
    private Long idSel(){ int vr=tbl.getSelectedRow(); if (vr==-1){ JOptionPane.showMessageDialog(this,"Selecciona una mascota."); return null;} int mr=tbl.convertRowIndexToModel(vr); Object v=model.getValueAt(mr,0); return v==null?null:Long.parseLong(String.valueOf(v)); }
    private void nuevo(){ 
        var form = new MascotaForm(this, null);
        form.setVisible(true);
        if (form.fueGuardado()) {
            try {
                srv.guardar(form.getMascota());
                refrescar();
                JOptionPane.showMessageDialog(this, "Mascota creada exitosamente.");
            } catch(Exception ex){ 
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
            }
        }
    }
    private void editar(){ 
        Long id=idSel(); if(id==null) return; 
        var m = srv.listar().stream().filter(x->x.getId().equals(id)).findFirst().orElse(null); 
        if(m==null) return; 
        var form = new MascotaForm(this, m);
        form.setVisible(true);
        if (form.fueGuardado()) {
            try {
                srv.guardar(form.getMascota());
                refrescar();
                JOptionPane.showMessageDialog(this, "Mascota actualizada exitosamente.");
            } catch(Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    private void cambiar(boolean a){ 
        Long id=idSel(); if(id==null) return; 
        try {
            srv.setActivo(id,a); 
            refrescar();
            JOptionPane.showMessageDialog(this, "Mascota " + (a ? "activada" : "inactivada") + " exitosamente.");
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void verHistorial() {
        // Restricción de rol
        boolean isMedico = actual.getRol() != null && "Médico".equalsIgnoreCase(actual.getRol().getName());
        if (!isMedico) {
            JOptionPane.showMessageDialog(this, "Solo médicos pueden ver el historial clínico.", "Acceso Denegado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Long id = idSel();
        if (id == null) return;
        
        Mascota mascota = srv.listar().stream()
            .filter(x -> x.getId().equals(id))
            .findFirst()
            .orElse(null);
            
        if (mascota == null) {
            JOptionPane.showMessageDialog(this, "No se encontró la mascota");
            return;
        }
        
        HistorialClinicoForm historialForm = new HistorialClinicoForm(mascota);
        historialForm.setVisible(true);
    }
}
