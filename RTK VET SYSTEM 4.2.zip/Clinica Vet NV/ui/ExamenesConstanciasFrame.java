package ui;

import javax.swing.*;
import java.awt.*;
import ui.utils.RTKColors;
import ui.utils.Theme;
import ui.utils.SessionUtil;
import model.services.IAuthService;
import model.services.ExamenService;
import model.repositories.h2.ExamenRepositoryH2;
import model.repositories.h2.MascotaRepositoryH2;
import model.entities.Examen;
import model.entities.Usuario;
import model.services.MascotaService;

/**
 * Frame básico para Exámenes y Constancias.
 * Provee un listado y un formulario simple para crear/registrar exámenes y emitir constancias.
 */
@SuppressWarnings("this-escape")
public class ExamenesConstanciasFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final IAuthService auth;
    private transient final Usuario actual;

    private final JTextField txtBuscar = new JTextField(18);
    private final JButton btnBuscar = ui.utils.Theme.createButton("Buscar");
    private final JButton btnNuevo = ui.utils.Theme.createButton("Nuevo Examen");
    private final JButton btnGenerarConstancia = ui.utils.Theme.createButton("Generar Constancia");

    private final DefaultListModel<String> listModel = new DefaultListModel<>();
    private final JList<String> lista = new JList<>(listModel);

    private transient final ExamenService examenService = new ExamenService(new ExamenRepositoryH2(), new MascotaRepositoryH2());
    private transient final MascotaService mascotaService = new MascotaService(new MascotaRepositoryH2(), new model.repositories.h2.DuenoRepositoryH2());

    public ExamenesConstanciasFrame(Usuario actual, IAuthService auth) {
        super("RTK - VET SYSTEM - Exámenes y Constancias");
        this.auth = auth;
        this.actual = actual;
        setSize(820, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Buscar:")); top.add(txtBuscar); top.add(btnBuscar);
        // header + top
        JPanel northContainer = new JPanel(new BorderLayout());
        northContainer.add(Theme.createHeaderPanel("RTK VET - Exámenes y Constancias", actual, () -> SessionUtil.cerrarSesion(this, auth)), BorderLayout.NORTH);
        northContainer.add(top, BorderLayout.SOUTH);
        add(northContainer, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(8,8));
        lista.setVisibleRowCount(10);
        center.add(new JScrollPane(lista), BorderLayout.CENTER);

        JPanel right = new JPanel();
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        right.add(btnNuevo); right.add(Box.createVerticalStrut(8)); right.add(btnGenerarConstancia);

    add(center, BorderLayout.CENTER);
    add(right, BorderLayout.EAST);

        // basic behavior: fill with sample data or keep empty
        listModel.addElement("Ejemplo: Examen Hematológico - Mascota #12 - 01/01/2025");

        btnBuscar.addActionListener(e -> refrescarLista());
        btnNuevo.addActionListener(e -> crearExamen());
        btnGenerarConstancia.addActionListener(e -> generarConstancia());

        // Role controls: only Médico or Auxiliar can create exams; constancia generator allowed for Médico
        boolean isMedico = actual != null && actual.getRol() != null && "Médico".equalsIgnoreCase(actual.getRol().getName());
        boolean isAux = actual != null && actual.getRol() != null && "Auxiliar".equalsIgnoreCase(actual.getRol().getName());
        btnNuevo.setEnabled(isMedico || isAux);
        if (!btnNuevo.isEnabled()) btnNuevo.setToolTipText("Solo Médicos y Auxiliares pueden registrar exámenes");
        btnGenerarConstancia.setEnabled(isMedico);
        if (!btnGenerarConstancia.isEnabled()) btnGenerarConstancia.setToolTipText("Solo Médicos pueden emitir constancias");

        // apply theme
        Theme.applyToFrame(this);

        // populate initial list
        refrescarLista();
    }

    private void refrescarLista() {
        listModel.clear();
        for (var e : examenService.listar()) {
            listModel.addElement(String.format("[%d] %s - Mascota#%d - %s", e.getId(), e.getDescripcion(), e.getMascotaId(), e.getFecha()));
        }
    }

    private void crearExamen() {
        JPanel p = new JPanel(new GridLayout(0,1,6,6));
        // Mascota selection dropdown
        JComboBox<String> cboMascotas = new JComboBox<>();
        cboMascotas.addItem("");
        var mascotas = mascotaService.listar();
        for (var m : mascotas) cboMascotas.addItem(m.getId() + " - " + m.getNombre());
        JTextField txtDescripcion = new JTextField();
        p.add(new JLabel("Mascota:")); p.add(cboMascotas);
        p.add(new JLabel("Descripción:")); p.add(txtDescripcion);
        int r = JOptionPane.showConfirmDialog(this, p, "Nuevo examen", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r == JOptionPane.OK_OPTION) {
            String desc = txtDescripcion.getText().trim();
            String sel = (String) cboMascotas.getSelectedItem();
            if (desc.isBlank() || sel == null || sel.isBlank()) {
                JOptionPane.showMessageDialog(this, "Completa los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Long mascotaId = Long.parseLong(sel.split("\\s*-\\s*")[0]);
            Examen ex = new Examen(); ex.setDescripcion(desc); ex.setMascotaId(mascotaId);
            try {
                examenService.crear(ex, actual);
                JOptionPane.showMessageDialog(this, "Examen guardado.");
                refrescarLista();
            } catch (Exception exx) {
                JOptionPane.showMessageDialog(this, "Error: " + exx.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void generarConstancia() {
        String sel = lista.getSelectedValue();
        if (sel == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un examen de la lista.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // Parse id from list item
        try {
            String idStr = sel.substring(sel.indexOf('[')+1, sel.indexOf(']'));
            Long id = Long.parseLong(idStr);
            var opt = examenService.buscar(id);
            if (opt.isEmpty()) { JOptionPane.showMessageDialog(this, "Examen no encontrado.", "Error", JOptionPane.ERROR_MESSAGE); return; }
            Examen e = opt.get();
            Examen constancia = new Examen();
            constancia.setMascotaId(e.getMascotaId());
            constancia.setDescripcion("Constancia: " + e.getDescripcion());
            constancia.setTipo("CONSTANCIA");
            examenService.crear(constancia, actual);
            JOptionPane.showMessageDialog(this, "Constancia generada para examen #" + e.getId(), "Constancia", JOptionPane.INFORMATION_MESSAGE);
            refrescarLista();
        } catch (Exception ex){ JOptionPane.showMessageDialog(this, "Error al generar constancia: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }
}
