
package ui;
import java.awt.*;
import java.time.*;
import javax.swing.*;
import javax.swing.table.*;
import model.entities.Cita;
import model.entities.Usuario;
import model.repositories.h2.CitaRepositoryH2;
import model.repositories.h2.MascotaRepositoryH2;
import model.repositories.h2.UsuarioRepositoryH2;
import model.services.CitaService;
import model.services.IAuthService;
import model.services.ICitaService;
import model.services.UsuarioService;
import ui.forms.CitaForm;
import ui.forms.ValoracionMedicaForm;
import ui.utils.DateUtil;
import ui.utils.RTKColors;
import ui.utils.SessionUtil;
import ui.utils.Theme;

@SuppressWarnings("this-escape")
public class CitasFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final ICitaService srv = new CitaService(new CitaRepositoryH2(), new MascotaRepositoryH2());
    private transient final UsuarioService usuarioService = new UsuarioService(new UsuarioRepositoryH2());
    private final JTextField txtFecha = new JTextField(10);
    private final JComboBox<String> cboMedico = new JComboBox<>();
    private final JButton btnVerDia = ui.utils.Theme.createButton("Ver día");
    private final JButton btnNueva  = ui.utils.Theme.createButton("Nueva");
    private final JButton btnConfirm= ui.utils.Theme.createButton("Confirmar");
    private final JButton btnAtender= ui.utils.Theme.createButton("Atender");
    private final JButton btnCancelar= ui.utils.Theme.createButton("Cancelar");

    private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID","Fecha","Hora","Min","Médico","Mascota","Motivo","Estado"},0){ @Override public boolean isCellEditable(int r,int c){ return false; }};
    private final JTable tbl = new JTable(model);
    private transient final Usuario actual;
    @SuppressWarnings("unused")
    private transient final IAuthService auth;

    public CitasFrame(Usuario actual, IAuthService auth){
        super("RTK - VET SYSTEM - Gestión de Citas");
        this.actual=actual;
        this.auth = auth;
        setSize(980,560); setLocationRelativeTo(null); setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cargarMedicos();
        // Establecer fecha por defecto al día actual
        txtFecha.setText(DateUtil.format(LocalDate.now()));
    var top=new JPanel(new FlowLayout(FlowLayout.LEFT)); top.add(new JLabel("Fecha (DD/MM/AAAA):")); top.add(txtFecha); top.add(new JLabel("Médico:")); top.add(cboMedico); top.add(btnVerDia);
    var btnCerrarSesion = ui.utils.Theme.createButton("Cerrar sesión");
    top.add(new JLabel("  ")); top.add(btnCerrarSesion);
    var bar=new JPanel(new FlowLayout(FlowLayout.LEFT)); for (var b:new JButton[]{btnNueva,btnConfirm,btnAtender,btnCancelar}){ bar.add(b); }
        btnCerrarSesion.addActionListener(e -> SessionUtil.cerrarSesion(this, auth));
        tbl.setRowHeight(26); tbl.getTableHeader().setBackground(RTKColors.LIGHT_BLUE); tbl.getTableHeader().setForeground(RTKColors.DARK_GRAY);
    // Header + top container: header from Theme plus the existing top controls
    JPanel northContainer = new JPanel(new BorderLayout());
    northContainer.add(ui.utils.Theme.createHeaderPanel("RTK VET - Gestión de Citas", actual, () -> ui.utils.SessionUtil.cerrarSesion(CitasFrame.this, auth)), BorderLayout.NORTH);
    northContainer.add(top, BorderLayout.SOUTH);
    add(northContainer, BorderLayout.NORTH);
    add(new JScrollPane(tbl), BorderLayout.CENTER); add(bar, BorderLayout.SOUTH);
        btnVerDia.addActionListener(e->cargarDia()); btnNueva.addActionListener(e->nueva()); btnConfirm.addActionListener(e->cambiar("CONFIRMADA")); btnAtender.addActionListener(e->cambiar("ATENDIDA")); btnCancelar.addActionListener(e->cambiar("CANCELADA"));
        // Restricción de rol: solo médicos pueden atender citas
        boolean isMedico = actual.getRol() != null && "Médico".equalsIgnoreCase(actual.getRol().getName());
        btnAtender.setEnabled(isMedico);
        if (!isMedico) {
            btnAtender.setToolTipText("Solo médicos pueden atender citas");
        }
        // Notificación a Auxiliar (Observer): informar solo si la fecha de la cancelación
        // es mayor o igual a la fecha que el auxiliar está viendo en la UI
        if (actual.getRol()!=null && "Auxiliar".equalsIgnoreCase(actual.getRol().getName())){
            ((CitaService)srv).notifier().addObserver((fecha, medico)-> {
                SwingUtilities.invokeLater(() -> {
                    try {
                        java.time.LocalDate vista = DateUtil.parse(txtFecha.getText().trim());
                        if (vista == null) vista = java.time.LocalDate.now();
                        if (fecha != null && (fecha.isEqual(vista) || fecha.isAfter(vista))) {
                            JOptionPane.showMessageDialog(this, "Se liberó cupo por cancelación para el día " + DateUtil.format(fecha) + " - Dr(a). " + medico, "Agenda", JOptionPane.INFORMATION_MESSAGE);
                        }
                    } catch(Exception ex) {
                        // en caso de error en parseo, notificar igualmente
                        JOptionPane.showMessageDialog(this, "Se liberó cupo por cancelación: " + DateUtil.format(fecha) + " - Dr(a). " + medico, "Agenda", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
            });
        }
        // Cargar citas del día actual al abrir
        cargarDia();
        Theme.applyToFrame(this);
    }
    // styling is applied via Theme.createButton / createHeaderPanel
    private void cargarDia(){
        model.setRowCount(0);
        try{
            LocalDate f = DateUtil.parse(txtFecha.getText().trim());
            if (f == null) {
                JOptionPane.showMessageDialog(this, "Fecha inválida. Use formato DD/MM/AAAA (ejemplo: 25/12/2024)", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String med = (cboMedico.getSelectedItem() != null) ? cboMedico.getSelectedItem().toString().trim() : "";
            for (var c: srv.agendaDia(f, med.isBlank()? null : med)){
                model.addRow(new Object[]{ c.getId(), DateUtil.format(c.getFecha()), c.getHora(), c.getMinutos(), c.getMedico(), c.getMascotaId(), c.getMotivo(), c.getEstado() });
            }
        } catch(Exception ex){ JOptionPane.showMessageDialog(this, "Fecha inválida. Use formato DD/MM/AAAA (ejemplo: 25/12/2024)", "Error", JOptionPane.ERROR_MESSAGE); }
    }
    private Long idSel(){ int vr=tbl.getSelectedRow(); if (vr==-1){ JOptionPane.showMessageDialog(this,"Selecciona una cita."); return null;} int mr=tbl.convertRowIndexToModel(vr); Object v=model.getValueAt(mr,0); return v==null?null:Long.parseLong(String.valueOf(v)); }
    private void nueva(){
        var form = new CitaForm(this, null);
        form.setVisible(true);
        if (form.fueGuardado()) {
            try {
                Cita citaCreada = form.getCita();
                if (citaCreada == null) {
                    JOptionPane.showMessageDialog(this, "Error: No se pudo obtener la cita.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                srv.crear(citaCreada);
                // Establecer la fecha de la cita creada en el campo de fecha
                txtFecha.setText(DateUtil.format(citaCreada.getFecha()));
                // Seleccionar el médico de la cita creada
                String medicoNombre = citaCreada.getMedico();
                for (int i = 0; i < cboMedico.getItemCount(); i++) {
                    if (medicoNombre.equals(cboMedico.getItemAt(i))) {
                        cboMedico.setSelectedIndex(i);
                        break;
                    }
                }
                // Recargar la vista del día
                cargarDia();
                JOptionPane.showMessageDialog(this, "Cita creada exitosamente.");
            } catch(IllegalArgumentException ex){ 
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
            } catch(Exception ex){ 
                JOptionPane.showMessageDialog(this, "Error inesperado: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
                ex.printStackTrace();
            }
        }
    }
    private void cambiar(String nuevo){
        Long id = idSel(); if (id==null) return;
        // Restricción de rol para atender citas
        if ("ATENDIDA".equals(nuevo)) {
            boolean isMedico = actual.getRol() != null && "Médico".equalsIgnoreCase(actual.getRol().getName());
            if (!isMedico) {
                JOptionPane.showMessageDialog(this, "Solo médicos pueden atender citas.", "Acceso Denegado", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }
        switch (nuevo){
            case "CONFIRMADA": 
                srv.confirmar(id); 
                break;
            case "ATENDIDA": 
                // Obtener la cita
                Cita cita = srv.buscar(id).orElse(null);
                if (cita == null) {
                    JOptionPane.showMessageDialog(this, "No se encontró la cita");
                    return;
                }
                
                // Obtener la mascota
                var mascota = srv.buscarMascota(cita.getMascotaId()).orElse(null);
                if (mascota == null) {
                    JOptionPane.showMessageDialog(this, "No se encontró la mascota");
                    return;
                }
                
                // Mostrar formulario de valoración
                var valoracionForm = new ValoracionMedicaForm(cita, mascota, cita.getMedico(), () -> {
                    srv.atender(id);
                    cargarDia();
                });
                valoracionForm.setVisible(true);
                break;
            case "CANCELADA": 
                srv.cancelar(id); 
                cargarDia();
                break;
        }
    }
    
    private void cargarMedicos() {
        cboMedico.addItem(""); // Opción para ver todos los médicos
        var usuarios = usuarioService.listar();
        for (var u : usuarios) {
            if (u.isEnabled() && u.getRol() != null && "Médico".equalsIgnoreCase(u.getRol().getName())) {
                cboMedico.addItem(u.getNombre());
            }
        }
    }
}
