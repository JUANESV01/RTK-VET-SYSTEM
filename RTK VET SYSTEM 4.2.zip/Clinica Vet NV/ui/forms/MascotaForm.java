package ui.forms;
import java.awt.*;
import javax.swing.*;
import model.entities.Dueno;
import model.entities.Mascota;
import model.repositories.h2.DuenoRepositoryH2;
import model.services.DuenoService;

@SuppressWarnings("this-escape")
public class MascotaForm extends JDialog {
    private static final long serialVersionUID = 1L;
    private transient Mascota mascota;
    private boolean guardado = false;
    private transient DuenoService duenoService = new DuenoService(new DuenoRepositoryH2());
    
    private JTextField txtNombre = new JTextField(25);
    private JTextField txtEspecie = new JTextField(25);
    private JTextField txtRaza = new JTextField(25);
    private JComboBox<String> cboSexo = new JComboBox<>(new String[]{"", "Macho", "Hembra"});
    private JComboBox<DuenoItem> cboDueno = new JComboBox<>();
    private JTextField txtEdad = new JTextField(10);
    private JTextField txtPeso = new JTextField(10);
    private JTextArea txtVacunas = new JTextArea(3, 25);
    private JTextArea txtAlergias = new JTextArea(3, 25);
    private JTextArea txtObservaciones = new JTextArea(3, 25);
    private JButton btnGuardar = ui.utils.Theme.createButton("Guardar");
    private JButton btnCancelar = ui.utils.Theme.createButton("Cancelar");
    
    private static class DuenoItem {
        private Long id;
        private String nombre;
        public DuenoItem(Dueno d) { this.id = d.getId(); this.nombre = d.getNombre(); }
        public Long getId() { return id; }
        @Override public String toString() { return nombre; }
    }
    
    public MascotaForm(JFrame parent, Mascota m) {
        super(parent, "Mascota", true);
        this.mascota = m;
        setSize(450, 550);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        cargarDuenos();
        
        var panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        var c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        c.gridx = 0; c.gridy = row;
        panel.add(new JLabel("Nombre:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(txtNombre, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Especie:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(txtEspecie, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Raza:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(txtRaza, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Sexo:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(cboSexo, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Dueño:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(cboDueno, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Edad (años):"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(txtEdad, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Peso (kg):"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(txtPeso, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Vacunas:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(new JScrollPane(txtVacunas), c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Alergias:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(new JScrollPane(txtAlergias), c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Observaciones:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(new JScrollPane(txtObservaciones), c);
        row++;
        
    var btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    btnGuardar.setPreferredSize(new Dimension(100,30));
    btnCancelar.setPreferredSize(new Dimension(100,30));
    btnPanel.add(btnGuardar);
    btnPanel.add(btnCancelar);
        
        c.gridx = 0; c.gridy = row; c.gridwidth = 2; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(btnPanel, c);
        
        if (mascota != null) {
            txtNombre.setText(mascota.getNombre());
            txtEspecie.setText(mascota.getEspecie());
            txtRaza.setText(mascota.getRaza());
            if (mascota.getSexo() != null && !mascota.getSexo().isBlank()) {
                String sexo = mascota.getSexo();
                for (int i = 0; i < cboSexo.getItemCount(); i++) {
                    String item = cboSexo.getItemAt(i);
                    if (item != null && item.equalsIgnoreCase(sexo)) {
                        cboSexo.setSelectedIndex(i);
                        break;
                    }
                }
            }
            if (mascota.getEdadAnios() != null) txtEdad.setText(String.valueOf(mascota.getEdadAnios()));
            if (mascota.getPesoKg() != null) txtPeso.setText(String.valueOf(mascota.getPesoKg()));
            txtVacunas.setText(mascota.getVacunas());
            txtAlergias.setText(mascota.getAlergias());
            txtObservaciones.setText(mascota.getObservaciones());
            
            // Seleccionar dueño
            for (int i = 0; i < cboDueno.getItemCount(); i++) {
                if (cboDueno.getItemAt(i).getId().equals(mascota.getDuenoId())) {
                    cboDueno.setSelectedIndex(i);
                    break;
                }
            }
        }
        
        btnGuardar.addActionListener(e -> guardar());
        btnCancelar.addActionListener(e -> dispose());
        
        ui.utils.Theme.applyToWindow(this);
        add(panel);
    }
    
    private void cargarDuenos() {
        var duenos = duenoService.listar();
        for (var d : duenos) {
            if (d.isActivo()) {
                cboDueno.addItem(new DuenoItem(d));
            }
        }
    }
    
    // Buttons styled via Theme
    
    private void guardar() {
        if (txtNombre.getText().trim().isBlank()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txtEspecie.getText().trim().isBlank()) {
            JOptionPane.showMessageDialog(this, "La especie es obligatoria.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (cboDueno.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un dueño.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (mascota == null) {
            mascota = new Mascota();
        }
        mascota.setNombre(txtNombre.getText().trim());
        mascota.setEspecie(txtEspecie.getText().trim());
        mascota.setRaza(txtRaza.getText().trim().isBlank() ? null : txtRaza.getText().trim());
        String sexo = (String)cboSexo.getSelectedItem();
        mascota.setSexo(sexo == null || sexo.isBlank() ? null : sexo);
        mascota.setDuenoId(((DuenoItem)cboDueno.getSelectedItem()).getId());
        
        try {
            if (!txtEdad.getText().trim().isBlank()) {
                mascota.setEdadAnios(Integer.parseInt(txtEdad.getText().trim()));
            }
        } catch (NumberFormatException e) {
            // Ignorar
        }
        
        try {
            if (!txtPeso.getText().trim().isBlank()) {
                mascota.setPesoKg(Double.parseDouble(txtPeso.getText().trim()));
            }
        } catch (NumberFormatException e) {
            // Ignorar
        }
        
        mascota.setVacunas(txtVacunas.getText().trim().isBlank() ? null : txtVacunas.getText().trim());
        mascota.setAlergias(txtAlergias.getText().trim().isBlank() ? null : txtAlergias.getText().trim());
        mascota.setObservaciones(txtObservaciones.getText().trim().isBlank() ? null : txtObservaciones.getText().trim());
        
        if (mascota.getId() == null) {
            mascota.setActivo(true);
        }
        
        guardado = true;
        dispose();
    }
    
    public Mascota getMascota() { return guardado ? mascota : null; }
    public boolean fueGuardado() { return guardado; }
}
