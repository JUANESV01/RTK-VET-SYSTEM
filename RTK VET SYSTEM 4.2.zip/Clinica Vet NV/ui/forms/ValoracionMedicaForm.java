package ui.forms;

import java.awt.*;
import java.time.LocalDateTime;
import javax.swing.*;
import model.entities.Cita;
import model.entities.Mascota;
import model.entities.ValoracionMedica;
import model.repositories.h2.ValoracionMedicaRepositoryH2;
import model.services.ValoracionMedicaService;

@SuppressWarnings("this-escape")
public class ValoracionMedicaForm extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final ValoracionMedicaService service = new ValoracionMedicaService(new ValoracionMedicaRepositoryH2());
    private transient final Cita cita;
    private transient final Mascota mascota;
    private final String medicoNombre;
    private transient final Runnable onSave;

    private final JTextArea txtMotivo = new JTextArea(3, 40);
    private final JTextArea txtSintomas = new JTextArea(4, 40);
    private final JTextArea txtDiagnostico = new JTextArea(4, 40);
    private final JTextArea txtTratamiento = new JTextArea(4, 40);
    private final JTextArea txtMedicamentos = new JTextArea(4, 40);
    private final JTextArea txtObservaciones = new JTextArea(3, 40);
    private final JButton btnGuardar = ui.utils.Theme.createButton("Guardar Valoración");

    public ValoracionMedicaForm(Cita cita, Mascota mascota, String medicoNombre, Runnable onSave) {
        super("Valoración Médica");
        this.cita = cita;
        this.mascota = mascota;
        this.medicoNombre = medicoNombre;
        this.onSave = onSave;

        setSize(600, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(5, 5, 5, 5);

        // Info del paciente
        addInfoSection(form, c);
        
        // Campos de valoración
        addField(form, c, "Motivo de consulta:", txtMotivo);
        addField(form, c, "Síntomas:", txtSintomas);
        addField(form, c, "Diagnóstico:", txtDiagnostico);
        addField(form, c, "Tratamiento:", txtTratamiento);
        addField(form, c, "Medicamentos:", txtMedicamentos);
        addField(form, c, "Observaciones:", txtObservaciones);

    // Panel de botones
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.CENTER;
    btnGuardar.setPreferredSize(new Dimension(160,32));
    form.add(btnGuardar, c);

    // Scroll
    JScrollPane scroll = new JScrollPane(form);
    scroll.setBorder(null);
    JPanel northContainer = new JPanel(new BorderLayout());
    northContainer.add(ui.utils.Theme.createHeaderPanel("RTK VET - Valoración Médica", null, null), BorderLayout.NORTH);
    northContainer.add(scroll, BorderLayout.CENTER);
    add(northContainer);

        btnGuardar.addActionListener(e -> guardar());

        // Si ya existe una valoración, cargarla
        service.buscarPorCita(cita.getId()).ifPresent(this::cargarValoracion);
    }

    private void addInfoSection(JPanel form, GridBagConstraints c) {
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        
        JPanel info = new JPanel(new GridLayout(3, 2, 10, 5));
        info.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Información del Paciente"),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        
        info.add(new JLabel("Mascota:"));
        info.add(new JLabel(mascota.getNombre()));
        info.add(new JLabel("Médico:"));
        info.add(new JLabel(medicoNombre));
        info.add(new JLabel("Fecha:"));
        info.add(new JLabel(cita.getFecha().toString() + " " + cita.getHora().toString()));
        
        form.add(info, c);
        c.gridy++;
    }

    private void addField(JPanel form, GridBagConstraints c, String label, JTextArea field) {
        c.gridx = 0;
        c.gridwidth = 2;
        form.add(new JLabel(label), c);
        
        c.gridy++;
        field.setLineWrap(true);
        field.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(field);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        form.add(scroll, c);
        
        c.gridy++;
    }

    // Buttons styled via Theme

    private void cargarValoracion(ValoracionMedica v) {
        txtMotivo.setText(v.getMotivo());
        txtSintomas.setText(v.getSintomas());
        txtDiagnostico.setText(v.getDiagnostico());
        txtTratamiento.setText(v.getTratamiento());
        txtMedicamentos.setText(v.getMedicamentos());
        txtObservaciones.setText(v.getObservaciones());
    }

    private void guardar() {
        try {
            ValoracionMedica valoracion = new ValoracionMedica();
            valoracion.setCitaId(cita.getId());
            valoracion.setMascotaId(mascota.getId());
            valoracion.setMedico(medicoNombre);
            valoracion.setFecha(LocalDateTime.now());
            valoracion.setMotivo(txtMotivo.getText().trim());
            valoracion.setSintomas(txtSintomas.getText().trim());
            valoracion.setDiagnostico(txtDiagnostico.getText().trim());
            valoracion.setTratamiento(txtTratamiento.getText().trim());
            valoracion.setMedicamentos(txtMedicamentos.getText().trim());
            valoracion.setObservaciones(txtObservaciones.getText().trim());

            service.guardar(valoracion);
            if (onSave != null) onSave.run();
            dispose();
            JOptionPane.showMessageDialog(this, 
                "Valoración guardada exitosamente", 
                "Éxito", 
                JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al guardar la valoración: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}