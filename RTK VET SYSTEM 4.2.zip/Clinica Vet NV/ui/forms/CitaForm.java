package ui.forms;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import javax.swing.*;
import model.entities.Cita;
import model.entities.Mascota;
import model.repositories.h2.DuenoRepositoryH2;
import model.repositories.h2.MascotaRepositoryH2;
import model.repositories.h2.UsuarioRepositoryH2;
import model.services.MascotaService;
import model.services.UsuarioService;
import ui.utils.DateUtil;

@SuppressWarnings("this-escape")
public class CitaForm extends JDialog {
    private static final long serialVersionUID = 1L;
    private transient Cita cita;
    private boolean guardado = false;
    private transient MascotaService mascotaService = new MascotaService(new MascotaRepositoryH2(), new DuenoRepositoryH2());
    private transient UsuarioService usuarioService = new UsuarioService(new UsuarioRepositoryH2());
    
    private JTextField txtFecha = new JTextField(12);
    private JTextField txtHora = new JTextField(8);
    private JTextField txtMinutos = new JTextField(8);
    private JComboBox<String> cboMedico = new JComboBox<>();
    private JComboBox<MascotaItem> cboMascota = new JComboBox<>();
    private JTextArea txtMotivo = new JTextArea(4, 25);
    private JButton btnGuardar = ui.utils.Theme.createButton("Guardar");
    private JButton btnCancelar = ui.utils.Theme.createButton("Cancelar");
    
    private static class MascotaItem {
        private Long id;
        private String nombre;
        public MascotaItem(Mascota m) { this.id = m.getId(); this.nombre = m.getNombre() + " (" + m.getEspecie() + ")"; }
        public Long getId() { return id; }
        @Override public String toString() { return nombre; }
    }
    
    public CitaForm(JFrame parent, Cita c) {
        super(parent, "Cita", true);
        this.cita = c;
        setSize(450, 350);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        cargarMascotas();
        cargarMedicos();
        
        var panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        var gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Fecha (DD/MM/AAAA):"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        panel.add(txtFecha, gbc);
        row++;
        
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Hora (HH:MM):"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        panel.add(txtHora, gbc);
        row++;
        
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Duración (minutos):"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        panel.add(txtMinutos, gbc);
        row++;
        
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Médico:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        panel.add(cboMedico, gbc);
        row++;
        
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Mascota:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        panel.add(cboMascota, gbc);
        row++;
        
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Motivo:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        panel.add(new JScrollPane(txtMotivo), gbc);
        row++;
        
    var btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    btnGuardar.setPreferredSize(new Dimension(100, 30));
    btnCancelar.setPreferredSize(new Dimension(100, 30));
    btnPanel.add(btnGuardar);
    btnPanel.add(btnCancelar);
        
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(btnPanel, gbc);
        
        if (cita != null) {
            txtFecha.setText(DateUtil.format(cita.getFecha()));
            txtHora.setText(cita.getHora().toString());
            txtMinutos.setText(String.valueOf(cita.getMinutos()));
            txtMotivo.setText(cita.getMotivo());
            
            // Seleccionar médico
            String medicoNombre = cita.getMedico();
            for (int i = 0; i < cboMedico.getItemCount(); i++) {
                if (cboMedico.getItemAt(i).equals(medicoNombre)) {
                    cboMedico.setSelectedIndex(i);
                    break;
                }
            }
            
            // Seleccionar mascota
            for (int i = 0; i < cboMascota.getItemCount(); i++) {
                if (cboMascota.getItemAt(i).getId().equals(cita.getMascotaId())) {
                    cboMascota.setSelectedIndex(i);
                    break;
                }
            }
        } else {
            txtFecha.setText(DateUtil.format(LocalDate.now()));
            txtHora.setText("09:00");
            txtMinutos.setText("30");
        }
        
        btnGuardar.addActionListener(e -> guardar());
        btnCancelar.addActionListener(e -> dispose());
        
    ui.utils.Theme.applyToWindow(this);
        add(panel);
    }
    
    private void cargarMascotas() {
        var mascotas = mascotaService.listar();
        for (var m : mascotas) {
            if (m.isActivo()) {
                cboMascota.addItem(new MascotaItem(m));
            }
        }
    }
    
    private void cargarMedicos() {
        var usuarios = usuarioService.listar();
        for (var u : usuarios) {
            if (u.isEnabled() && u.getRol() != null && "Médico".equalsIgnoreCase(u.getRol().getName())) {
                cboMedico.addItem(u.getNombre());
            }
        }
    }
    
    // Buttons styled via Theme
    
    private void guardar() {
        try {
            if (txtFecha.getText().trim().isBlank()) {
                JOptionPane.showMessageDialog(this, "La fecha es obligatoria.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (txtHora.getText().trim().isBlank()) {
                JOptionPane.showMessageDialog(this, "La hora es obligatoria.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (cboMedico.getSelectedItem() == null || cboMedico.getSelectedItem().toString().trim().isBlank()) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar un médico.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (cboMascota.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar una mascota.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            LocalDate fecha;
            try {
                fecha = DateUtil.parse(txtFecha.getText().trim());
                if (fecha == null) {
                    JOptionPane.showMessageDialog(this, "Fecha inválida. Use formato DD/MM/AAAA (ejemplo: 25/12/2024)", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(this, "Fecha inválida: " + e.getMessage() + ". Use formato DD/MM/AAAA (ejemplo: 25/12/2024)", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            LocalTime hora;
            try {
                hora = LocalTime.parse(txtHora.getText().trim());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Hora inválida. Use formato HH:MM (ejemplo: 09:30)", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int minutos;
            try {
                minutos = Integer.parseInt(txtMinutos.getText().trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "La duración debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (minutos <= 0) {
                JOptionPane.showMessageDialog(this, "La duración debe ser mayor a 0.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (cita == null) {
                cita = new Cita();
            }
            cita.setFecha(fecha);
            cita.setHora(hora);
            cita.setMinutos(minutos);
            cita.setMedico(cboMedico.getSelectedItem().toString().trim());
            cita.setMascotaId(((MascotaItem)cboMascota.getSelectedItem()).getId());
            cita.setMotivo(txtMotivo.getText().trim().isBlank() ? null : txtMotivo.getText().trim());
            if (cita.getEstado() == null) {
                cita.setEstado("CREADA");
            }
            
            guardado = true;
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public Cita getCita() { return guardado ? cita : null; }
    public boolean fueGuardado() { return guardado; }
}
