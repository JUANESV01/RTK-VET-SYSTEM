package ui.forms;
import java.awt.*;
import javax.swing.*;
import model.entities.Dueno;

@SuppressWarnings("this-escape")
public class DuenoForm extends JDialog {
    private static final long serialVersionUID = 1L;
    private transient Dueno dueno;
    private boolean guardado = false;
    
    private JTextField txtNombre = new JTextField(25);
    private JTextField txtDocumento = new JTextField(25);
    private JTextField txtEmail = new JTextField(25);
    private JTextField txtTelefono = new JTextField(25);
    private JButton btnGuardar = ui.utils.Theme.createButton("Guardar");
    private JButton btnCancelar = ui.utils.Theme.createButton("Cancelar");
    
    public DuenoForm(JFrame parent, Dueno d) {
        super(parent, "Dueño", true);
        this.dueno = d;
        setSize(400, 180);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        var panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        var c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.anchor = GridBagConstraints.WEST;
        
    int row = 0;
        c.gridx = 0; c.gridy = row;
        panel.add(new JLabel("Nombre:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(txtNombre, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Documento:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(txtDocumento, c);
        row++;

    c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
    panel.add(new JLabel("Email:"), c);
    c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
    panel.add(txtEmail, c);
    row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Teléfono:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(txtTelefono, c);
        row++;
        
    var btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    btnGuardar.setPreferredSize(new Dimension(100,30));
    btnCancelar.setPreferredSize(new Dimension(100,30));
    btnPanel.add(btnGuardar);
    btnPanel.add(btnCancelar);
        
        c.gridx = 0; c.gridy = row; c.gridwidth = 2; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(btnPanel, c);
        
        if (dueno != null) {
            txtNombre.setText(dueno.getNombre());
            txtDocumento.setText(dueno.getDocumento());
            txtEmail.setText(dueno.getEmail());
            txtTelefono.setText(dueno.getTelefono());
        }
        
        btnGuardar.addActionListener(e -> guardar());
        btnCancelar.addActionListener(e -> dispose());
        ui.utils.Theme.applyToWindow(this);
        add(panel);
    }
    
    // Buttons styled via Theme
    
    private void guardar() {
        if (txtNombre.getText().trim().isBlank()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (dueno == null) {
            dueno = new Dueno();
        }
        dueno.setNombre(txtNombre.getText().trim());
    dueno.setDocumento(txtDocumento.getText().trim().isBlank() ? null : txtDocumento.getText().trim());
    dueno.setEmail(txtEmail.getText().trim().isBlank() ? null : txtEmail.getText().trim());
    dueno.setTelefono(txtTelefono.getText().trim().isBlank() ? null : txtTelefono.getText().trim());
        if (dueno.getId() == null) {
            dueno.setActivo(true);
        }
        
        guardado = true;
        dispose();
    }
    
    public Dueno getDueno() { return guardado ? dueno : null; }
    public boolean fueGuardado() { return guardado; }
}
