package ui.forms;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.entities.Dueno;
import model.entities.Factura;
import model.entities.FacturaItem;
import model.entities.Mascota;
import model.repositories.h2.DuenoRepositoryH2;
import model.repositories.h2.FacturacionRepositoryH2;
import model.repositories.h2.MascotaRepositoryH2;
import model.services.DuenoService;
import model.services.FacturacionService;
import model.services.IFacturacionService;
import model.services.MascotaService;
import ui.utils.RTKColors;

@SuppressWarnings("this-escape")
public class FacturaForm extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final DuenoService duenoService;
    private transient final MascotaService mascotaService;
    private transient final IFacturacionService factService;
    private transient final Runnable onSaved;

    private final JComboBox<Dueno> cboDueno = new JComboBox<>();
    private final JComboBox<Mascota> cboMascota = new JComboBox<>();
    private final DefaultTableModel mItems = new DefaultTableModel(new String[]{"Tipo","Descripción","Cant","Precio","Subtotal"},0){ @Override public boolean isCellEditable(int r,int c){ return c<4; } @Override public Class<?> getColumnClass(int c){ if (c==2) return Integer.class; if (c==3||c==4) return Double.class; return String.class; }};
    private final JTable tblItems = new JTable(mItems);
    private final JButton btnAdd = ui.utils.Theme.createButton("+ Ítem"), btnDel = ui.utils.Theme.createButton("Quitar ítem"), btnGuardar = ui.utils.Theme.createButton("Guardar factura"), btnCancelar = ui.utils.Theme.createButton("Cancelar");
    private final JLabel lblTotal = new JLabel("$ 0.00");

    public FacturaForm() {
        this(null);
    }

    public FacturaForm(Runnable onSaved) {
        super("Nueva Factura");
        this.duenoService = new DuenoService(new DuenoRepositoryH2());
        this.mascotaService = new MascotaService(new MascotaRepositoryH2(), new DuenoRepositoryH2());
        this.factService = new FacturacionService(new FacturacionRepositoryH2());
        this.onSaved = onSaved;

        setSize(800,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

    JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Dueño:")); top.add(cboDueno);
        top.add(new JLabel("Mascota:")); top.add(cboMascota);

        JPanel center = new JPanel(new BorderLayout());
    tblItems.setRowHeight(24);
    tblItems.getTableHeader().setBackground(RTKColors.LIGHT_BLUE);
    tblItems.getTableHeader().setForeground(RTKColors.DARK_GRAY);
        center.add(new JScrollPane(tblItems), BorderLayout.CENTER);

    var bar = new JPanel(new FlowLayout(FlowLayout.LEFT));
    btnAdd.setPreferredSize(new Dimension(120,30)); btnDel.setPreferredSize(new Dimension(120,30));
    bar.add(btnAdd); bar.add(btnDel);
        center.add(bar, BorderLayout.SOUTH);

        var south = new JPanel(new BorderLayout());
    var southBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    btnCancelar.setPreferredSize(new Dimension(120,30)); btnGuardar.setPreferredSize(new Dimension(140,30));
    southBtns.add(btnCancelar); southBtns.add(btnGuardar);
        var southLeft = new JPanel(new FlowLayout(FlowLayout.LEFT));
        southLeft.add(new JLabel("Total: ")); southLeft.add(lblTotal);
        south.add(southLeft, BorderLayout.WEST);
        south.add(southBtns, BorderLayout.EAST);

    JPanel northContainer = new JPanel(new BorderLayout());
    northContainer.add(ui.utils.Theme.createHeaderPanel("RTK VET - Nueva Factura", null, null), BorderLayout.NORTH);
    northContainer.add(top, BorderLayout.SOUTH);
    add(northContainer, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);

        // Load owners
        for (Dueno d : duenoService.listar()) cboDueno.addItem(d);

        cboDueno.addActionListener(e -> onDuenoSelected());
        btnAdd.addActionListener(e -> onAddItem());
        btnDel.addActionListener(e -> { int r = tblItems.getSelectedRow(); if (r!=-1) { mItems.removeRow(r); recalcTotals(); } });
        btnCancelar.addActionListener(e -> dispose());
        btnGuardar.addActionListener(e -> onGuardar());

        // Update subtotal and total when item quantity or price changes
        mItems.addTableModelListener(e -> {
            int col = e.getColumn();
            if (col == 2 || col == 3) {
                int row = e.getFirstRow();
                try {
                    int cant = Integer.parseInt(String.valueOf(mItems.getValueAt(row,2)));
                    double precio = Double.parseDouble(String.valueOf(mItems.getValueAt(row,3)));
                    double sub = cant * precio;
                    mItems.setValueAt(sub, row, 4);
                } catch(Exception ex) {
                    // ignore parse errors
                }
                recalcTotals();
            }
        });

        // renderers to show names
        cboDueno.setRenderer((list, value, index, isSelected, cellHasFocus) -> new JLabel(value==null?"":value.getNombre()));
        cboMascota.setRenderer((list, value, index, isSelected, cellHasFocus) -> new JLabel(value==null?"":value.getNombre()));
    }

    // Buttons styled via Theme

    private void onDuenoSelected(){
        cboMascota.removeAllItems();
        Dueno d = (Dueno)cboDueno.getSelectedItem();
        if (d==null) return;
        List<Mascota> mascotas = mascotaService.porDueno(d.getId());
        for (Mascota m : mascotas) cboMascota.addItem(m);
    }

    private void onAddItem(){
        // Dialog to add item
        JTextField txtDesc = new JTextField(30);
        JComboBox<String> cboTipo = new JComboBox<>(new String[]{"Medicamento","Producto","Consulta"});
        JSpinner spCant = new JSpinner(new SpinnerNumberModel(1,1,999,1));
        JSpinner spPrecio = new JSpinner(new SpinnerNumberModel(0.0,0.0,100000.0,0.5));
        JPanel p = new JPanel(new GridBagLayout()); GridBagConstraints c = new GridBagConstraints(); c.insets = new Insets(4,4,4,4); c.gridx=0; c.gridy=0; p.add(new JLabel("Tipo:"),c); c.gridx=1; p.add(cboTipo,c);
        c.gridx=0; c.gridy++; p.add(new JLabel("Descripción:"),c); c.gridx=1; p.add(txtDesc,c);
        c.gridx=0; c.gridy++; p.add(new JLabel("Cantidad:"),c); c.gridx=1; p.add(spCant,c);
        c.gridx=0; c.gridy++; p.add(new JLabel("Precio:"),c); c.gridx=1; p.add(spPrecio,c);
        int opt = JOptionPane.showConfirmDialog(this, p, "Agregar ítem", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (opt==JOptionPane.OK_OPTION){
            String tipo = (String)cboTipo.getSelectedItem();
            String desc = txtDesc.getText().trim();
            int cant = (Integer)spCant.getValue();
            double precio = ((Number)spPrecio.getValue()).doubleValue();
            double sub = cant * precio;
            mItems.addRow(new Object[]{ tipo, desc, cant, precio, sub });
        }
    }

    private void onGuardar(){
        try{
            Dueno d = (Dueno)cboDueno.getSelectedItem();
            if (d==null) { JOptionPane.showMessageDialog(this, "Seleccione un dueño"); return; }
            Mascota m = (Mascota)cboMascota.getSelectedItem();
            if (m==null) { JOptionPane.showMessageDialog(this, "Seleccione una mascota"); return; }
            if (mItems.getRowCount()==0){ JOptionPane.showMessageDialog(this, "Agregue al menos un ítem"); return; }

            List<FacturaItem> items = new ArrayList<>();
            for (int i=0;i<mItems.getRowCount();i++){
                FacturaItem it = new FacturaItem();
                it.setDescripcion(String.valueOf(mItems.getValueAt(i,1)));
                it.setCantidad(Integer.parseInt(String.valueOf(mItems.getValueAt(i,2))));
                it.setPrecio(Double.parseDouble(String.valueOf(mItems.getValueAt(i,3))));
                items.add(it);
            }

            Factura f = new Factura();
            f.setDuenoId(d.getId());
            f.setDuenoNombre(d.getNombre());
            f.setEstado("EMITIDA");
            f.setFormaPago(null);
            f.setObservaciones(null);
            f.setFecha(java.time.LocalDate.now());

            // validate items
            for (int i=0;i<items.size();i++){
                FacturaItem it = items.get(i);
                if (it.getDescripcion()==null || it.getDescripcion().trim().isEmpty()){
                    JOptionPane.showMessageDialog(this, "La descripción del ítem " + (i+1) + " es obligatoria");
                    return;
                }
                if (it.getCantidad() <= 0){ JOptionPane.showMessageDialog(this, "La cantidad del ítem " + (i+1) + " debe ser mayor que 0"); return; }
                if (it.getPrecio() <= 0.0){ JOptionPane.showMessageDialog(this, "El precio del ítem " + (i+1) + " debe ser mayor que 0"); return; }
            }

            factService.crearFactura(f, items);
            JOptionPane.showMessageDialog(this, "Factura creada #"+f.getId());
            if (onSaved != null) {
                try { onSaved.run(); } catch(Exception ex){ /* ignore callback errors */ }
            }
            dispose();
        } catch(Exception ex){ 
            ex.printStackTrace(); // Print stack trace to console for debugging
            JOptionPane.showMessageDialog(this, "Error al guardar factura: "+ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
        }
    }

    private void recalcTotals(){
        double total = 0.0;
        for (int i=0;i<mItems.getRowCount();i++){
            try{
                Object oSub = mItems.getValueAt(i,4);
                double sub = oSub==null?0.0:Double.parseDouble(String.valueOf(oSub));
                total += sub;
            }catch(Exception ex){ }
        }
        lblTotal.setText(String.format("$ %.2f", total));
    }
}
