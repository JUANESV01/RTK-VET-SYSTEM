package ui.forms;
import java.awt.*;
import javax.swing.*;
import model.entities.Usuario;
import model.repositories.h2.RolRepositoryH2;
import model.services.RolService;

@SuppressWarnings("this-escape")
public class UsuarioForm extends JDialog {
    private static final long serialVersionUID = 1L;
    private transient Usuario usuario;
    private boolean guardado = false;
    private boolean esNuevo;
    private transient RolService rolService = new RolService(new RolRepositoryH2());
    
    private JTextField txtEmail = new JTextField(25);
    private JTextField txtNombre = new JTextField(25);
    private JPasswordField txtPassword = new JPasswordField(25);
    private JComboBox<String> cboRol = new JComboBox<>(new String[]{"Administrador", "Médico", "Auxiliar"});
    private JCheckBox chkActivo = new JCheckBox("Activo");
    private JButton btnGuardar = ui.utils.Theme.createButton("Guardar");
    private JButton btnCancelar = ui.utils.Theme.createButton("Cancelar");
    
    public UsuarioForm(JFrame parent, Usuario u) {
        super(parent, "Usuario", true);
        this.usuario = u;
        this.esNuevo = (u == null);
        setSize(400, 220);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        var panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        var c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        c.gridx = 0; c.gridy = row;
        panel.add(new JLabel("Email:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        txtEmail.setEditable(esNuevo);
        panel.add(txtEmail, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Nombre:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(txtNombre, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel(esNuevo ? "Password:" : "Nueva Password:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        if (!esNuevo) {
            panel.add(new JLabel("(dejar vacío para no cambiar)"), c);
            row++;
            c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
            panel.add(new JLabel(""), c);
            c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        }
        panel.add(txtPassword, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel("Rol:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        panel.add(cboRol, c);
        row++;
        
        c.gridx = 0; c.gridy = row; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(new JLabel(""), c);
        c.gridx = 1; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        chkActivo.setSelected(true);
        panel.add(chkActivo, c);
        row++;
        
    var btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    btnGuardar.setPreferredSize(new Dimension(100,30));
    btnCancelar.setPreferredSize(new Dimension(100,30));
    btnPanel.add(btnGuardar);
    btnPanel.add(btnCancelar);
        
        c.gridx = 0; c.gridy = row; c.gridwidth = 2; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        panel.add(btnPanel, c);
        
        if (usuario != null) {
            txtEmail.setText(usuario.getEmail());
            txtNombre.setText(usuario.getNombre());
            if (usuario.getRol() != null) {
                String rolNombre = usuario.getRol().getName();
                for (int i = 0; i < cboRol.getItemCount(); i++) {
                    if (cboRol.getItemAt(i).equals(rolNombre)) {
                        cboRol.setSelectedIndex(i);
                        break;
                    }
                }
            }
            chkActivo.setSelected(usuario.isEnabled());
        }
        
        btnGuardar.addActionListener(e -> guardar());
        btnCancelar.addActionListener(e -> dispose());
        ui.utils.Theme.applyToWindow(this);
        add(panel);
    }
    
    // Buttons styled via Theme
    
    private void guardar() {
        if (txtEmail.getText().trim().isBlank()) {
            JOptionPane.showMessageDialog(this, "El email es obligatorio.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txtNombre.getText().trim().isBlank()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (esNuevo && txtPassword.getPassword().length == 0) {
            JOptionPane.showMessageDialog(this, "La password es obligatoria para nuevos usuarios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (usuario == null) {
            usuario = new Usuario();
        }
        usuario.setEmail(txtEmail.getText().trim());
        usuario.setNombre(txtNombre.getText().trim());
        if (esNuevo || txtPassword.getPassword().length > 0) {
            usuario.setPasswordHash(model.services.PasswordUtil.hash(new String(txtPassword.getPassword())));
        }
        usuario.setRol(rolService.ensure((String)cboRol.getSelectedItem()));
        usuario.setEnabled(chkActivo.isSelected());
        
        guardado = true;
        dispose();
    }
    
    public Usuario getUsuario() { return guardado ? usuario : null; }
    public boolean fueGuardado() { return guardado; }
    public boolean necesitaResetPassword() { return !esNuevo && txtPassword.getPassword().length > 0; }
    public String getNuevaPassword() { return new String(txtPassword.getPassword()); }
}
