package ui.forms;

import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import model.entities.Mascota;
import model.entities.ValoracionMedica;
import model.repositories.h2.ValoracionMedicaRepositoryH2;
import model.services.ValoracionMedicaService;
import ui.utils.RTKColors;

@SuppressWarnings("this-escape")
public class HistorialClinicoForm extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final ValoracionMedicaService service = new ValoracionMedicaService(new ValoracionMedicaRepositoryH2());
    private transient final Mascota mascota;
    private final JPanel historialPanel = new JPanel();
    private transient final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public HistorialClinicoForm(Mascota mascota) {
        super("Historial Clínico - " + mascota.getNombre());
        this.mascota = mascota;

        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

    // Panel principal con scroll
    historialPanel.setLayout(new BoxLayout(historialPanel, BoxLayout.Y_AXIS));
    JScrollPane scroll = new JScrollPane(historialPanel);
    scroll.setBorder(null);
    // header
    JPanel northContainer = new JPanel(new BorderLayout());
    northContainer.add(ui.utils.Theme.createHeaderPanel("RTK VET - Historial Clínico", null, null), BorderLayout.NORTH);
    northContainer.add(scroll, BorderLayout.CENTER);
    add(northContainer);

        // Cargar historial
        cargarHistorial();
        ui.utils.Theme.applyToFrame(this);
    }

    private void cargarHistorial() {
        List<ValoracionMedica> historial = service.obtenerHistorialMedico(mascota.getId());
        
        if (historial.isEmpty()) {
            historialPanel.add(crearPanelSinHistorial());
        } else {
            for (ValoracionMedica v : historial) {
                historialPanel.add(crearPanelValoracion(v));
            }
        }
    }

    private JPanel crearPanelSinHistorial() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel label = new JLabel("No hay registros clínicos para esta mascota", SwingConstants.CENTER);
        label.setFont(new Font(label.getFont().getName(), Font.ITALIC, 14));
        panel.add(label, BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel crearPanelValoracion(ValoracionMedica v) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        // Encabezado con fecha y médico
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel fechaLabel = new JLabel(v.getFecha().format(formatter));
        fechaLabel.setFont(new Font(fechaLabel.getFont().getName(), Font.BOLD, 12));
        JLabel medicoLabel = new JLabel(" | Médico: " + v.getMedico());
        header.add(fechaLabel);
        header.add(medicoLabel);
        panel.add(header, BorderLayout.NORTH);

        // Contenido principal
        JPanel content = new JPanel(new GridLayout(0, 1, 5, 5));
        content.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        addSeccion(content, "Motivo de consulta:", v.getMotivo());
        addSeccion(content, "Síntomas:", v.getSintomas());
        addSeccion(content, "Diagnóstico:", v.getDiagnostico());
        addSeccion(content, "Tratamiento:", v.getTratamiento());
        addSeccion(content, "Medicamentos:", v.getMedicamentos());
        if (v.getObservaciones() != null && !v.getObservaciones().trim().isEmpty()) {
            addSeccion(content, "Observaciones:", v.getObservaciones());
        }

        panel.add(content, BorderLayout.CENTER);
        
        // Agregar un espacio al final
        panel.add(Box.createVerticalStrut(10), BorderLayout.SOUTH);
        
        return panel;
    }

    private void addSeccion(JPanel panel, String titulo, String contenido) {
        if (contenido != null && !contenido.trim().isEmpty()) {
            JLabel tituloLabel = new JLabel(titulo);
            tituloLabel.setForeground(RTKColors.PRIMARY_BLUE);
            tituloLabel.setFont(new Font(tituloLabel.getFont().getName(), Font.BOLD, 12));
            panel.add(tituloLabel);

            JTextArea contenidoArea = new JTextArea(contenido);
            contenidoArea.setEditable(false);
            contenidoArea.setWrapStyleWord(true);
            contenidoArea.setLineWrap(true);
            contenidoArea.setBackground(panel.getBackground());
            contenidoArea.setBorder(BorderFactory.createEmptyBorder(0, 10, 5, 10));
            panel.add(contenidoArea);
        }
    }
}