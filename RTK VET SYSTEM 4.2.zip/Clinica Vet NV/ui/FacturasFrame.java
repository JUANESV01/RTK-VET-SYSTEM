
package ui;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.*;
import model.entities.Factura;
import model.entities.FacturaItem;
import model.entities.Usuario;
import model.repositories.h2.DuenoRepositoryH2;
import model.repositories.h2.FacturacionRepositoryH2;
import model.repositories.h2.MascotaRepositoryH2;
import model.services.DuenoService;
import model.services.FacturacionService;
import model.services.IAuthService;
import model.services.IFacturacionService;
import model.services.MascotaService;
import ui.utils.DateUtil;
import ui.utils.RTKColors;
import ui.utils.SessionUtil;
import ui.utils.Theme;

@SuppressWarnings("this-escape")
public class FacturasFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final IFacturacionService srv = new FacturacionService(new FacturacionRepositoryH2());
    private transient final DuenoService duenoService = new DuenoService(new DuenoRepositoryH2());
    private transient final MascotaService mascotaService = new MascotaService(new MascotaRepositoryH2(), new DuenoRepositoryH2());
    private transient final IAuthService auth;
    private transient final Usuario actual;
    private final JTextField txtDesde=new JTextField(10), txtHasta=new JTextField(10), txtDueno=new JTextField(12);
    private final JComboBox<String> cboEstado=new JComboBox<>(new String[]{"","EMITIDA","PAGADA","ANULADA"});
    private final JButton btnBuscar=ui.utils.Theme.createButton("Buscar"), btnNueva=ui.utils.Theme.createButton("Nueva factura"), btnPagar=ui.utils.Theme.createButton("Marcar PAGADA"), btnAnular=ui.utils.Theme.createButton("Anular"), btnGuardar=ui.utils.Theme.createButton("Guardar"), btnAddItem=ui.utils.Theme.createButton("+ Ítem"), btnDelItem=ui.utils.Theme.createButton("Quitar ítem");
    private final DefaultTableModel mFact=new DefaultTableModel(new String[]{"ID","Fecha","Dueño","Estado","Forma Pago","Total"},0){ @Override public boolean isCellEditable(int r,int c){return false;}};
    private final JTable tblFact=new JTable(mFact);
    private final DefaultTableModel mItems=new DefaultTableModel(new String[]{"Descripción","Cant","Precio","Subtotal"},0){ @Override public boolean isCellEditable(int r,int c){return c<3;} @Override public Class<?> getColumnClass(int col){ return (col==1)?Integer.class: (col>=2? Double.class : String.class);} };
    private final JTable tblItems=new JTable(mItems);
    private final JTextField txtDuenoId=new JTextField(6), txtForma=new JTextField(10);
    private final JTextArea txtObs=new JTextArea(4,18);
    private final JLabel lblTotal=new JLabel("$ 0.00");

    public FacturasFrame(IAuthService auth, Usuario actual){
        super("RTK - VET SYSTEM - Gestión de Facturación");
        this.auth = auth;
        this.actual = actual;
        setSize(980,560); setLocationRelativeTo(null); setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    var top=new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Desde (DD/MM/AAAA):")); top.add(txtDesde);
        top.add(new JLabel("Hasta:")); top.add(txtHasta);
        top.add(new JLabel("Estado:")); top.add(cboEstado);
        top.add(new JLabel("Dueño:")); top.add(txtDueno);
    top.add(btnBuscar);
    var btnCerrarSesion = ui.utils.Theme.createButton("Cerrar sesión");
    top.add(new JLabel("  ")); top.add(btnCerrarSesion);
        btnCerrarSesion.addActionListener(e -> SessionUtil.cerrarSesion(this, auth));

        tblFact.setRowHeight(26); tblFact.getTableHeader().setBackground(RTKColors.LIGHT_BLUE); tblFact.getTableHeader().setForeground(RTKColors.DARK_GRAY);
    var left=new JPanel(new BorderLayout()); left.add(new JScrollPane(tblFact), BorderLayout.CENTER);
    var leftBtns=new JPanel(new FlowLayout(FlowLayout.LEFT)); for(var b:new JButton[]{btnNueva,btnPagar,btnAnular}){ leftBtns.add(b);} left.add(leftBtns, BorderLayout.SOUTH);
    // Permisos: solo auxiliares pueden manejar facturación
        boolean isAux = actual != null && actual.getRol() != null && "Auxiliar".equalsIgnoreCase(actual.getRol().getName());
        btnNueva.setEnabled(isAux);
        btnPagar.setEnabled(isAux);
        btnAnular.setEnabled(isAux);
        if (!isAux) {
            btnNueva.setToolTipText("Solo auxiliares pueden crear facturas");
            btnPagar.setToolTipText("Solo auxiliares pueden marcar pagos");
            btnAnular.setToolTipText("Solo auxiliares pueden anular facturas");
        }
    JPanel northContainer = new JPanel(new BorderLayout());
    northContainer.add(ui.utils.Theme.createHeaderPanel("RTK VET - Gestión de Facturación", actual, () -> SessionUtil.cerrarSesion(FacturasFrame.this, auth)), BorderLayout.NORTH);
    northContainer.add(top, BorderLayout.SOUTH);
    add(northContainer, BorderLayout.NORTH); add(left, BorderLayout.CENTER);

        btnBuscar.addActionListener(e->refrescar());
    btnNueva.addActionListener(e->nueva());
        btnPagar.addActionListener(e->cambiar("PAGADA"));
        btnAnular.addActionListener(e->cambiar("ANULADA"));
        btnAddItem.addActionListener(e->mItems.addRow(new Object[]{"",1,0.0,0.0}));
        btnDelItem.addActionListener(e->{ int i=tblItems.getSelectedRow(); if(i!=-1) mItems.removeRow(i); calcTotal(); });
        btnGuardar.addActionListener(e->guardar());
        mItems.addTableModelListener(e -> {
            // Evitar recursión: los cambios que actualizan la columna subtotal (índice 3)
            // no deben volver a disparar el cálculo total.
            if (e.getColumn() == 3) return;
            calcTotal();
        });

        refrescar();
        Theme.applyToFrame(this);
    }
    // Styling delegated to Theme
    private void refrescar(){
        mFact.setRowCount(0);
        java.time.LocalDate d = parse(txtDesde.getText().trim());
        java.time.LocalDate h = parse(txtHasta.getText().trim());
        String e = (String)cboEstado.getSelectedItem(); if (e!=null && e.isBlank()) e=null;
        String du = txtDueno.getText().trim();
        for (var f : srv.listar(d,h,e,du)){
            mFact.addRow(new Object[]{ f.getId(), DateUtil.format(f.getFecha()), (f.getDuenoNombre()!=null?f.getDuenoNombre():"#"+f.getDuenoId()), f.getEstado(), f.getFormaPago(), f.getTotal() });
        }
    }
    private void nueva(){ 
        // Seguridad adicional: validar rol
        boolean isAux = actual != null && actual.getRol() != null && "Auxiliar".equalsIgnoreCase(actual.getRol().getName());
        if (!isAux) {
            JOptionPane.showMessageDialog(this, "Solo auxiliares pueden crear facturas.", "Acceso Denegado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // Abrir formulario completo para crear factura y refrescar al guardar
        ui.forms.FacturaForm form = new ui.forms.FacturaForm(() -> {
            SwingUtilities.invokeLater(() -> {
                try { refrescar(); } catch(Exception ex) { /* ignore */ }
            });
        });
        form.setVisible(true);
    }
    private void guardar(){
        try{
            if (txtDuenoId.getText().trim().isBlank()) {
                JOptionPane.showMessageDialog(this, "Debe ingresar un ID de dueño.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            long duenoId = Long.parseLong(txtDuenoId.getText().trim());
            if (duenoService.listar().stream().noneMatch(d -> d.getId().equals(duenoId))) {
                JOptionPane.showMessageDialog(this, "El dueño con ID " + duenoId + " no existe.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (mItems.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Debe agregar al menos un ítem a la factura.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String forma = txtForma.getText().trim();
            String obs = txtObs.getText().trim();
            java.util.List<FacturaItem> items = new ArrayList<>();
            for (int i=0;i<mItems.getRowCount();i++){
                String desc = String.valueOf(mItems.getValueAt(i,0)).trim();
                if (desc.isBlank()) {
                    JOptionPane.showMessageDialog(this, "La descripción del ítem en la fila " + (i+1) + " no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                var it = new FacturaItem(); 
                it.setDescripcion(desc);
                try {
                    it.setCantidad(Integer.parseInt(String.valueOf(mItems.getValueAt(i,1))));
                    it.setPrecio(Double.parseDouble(String.valueOf(mItems.getValueAt(i,2))));
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Error en los valores numéricos del ítem en la fila " + (i+1) + ".", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                items.add(it);
            }
            var f = new Factura(); f.setDuenoId(duenoId); f.setFormaPago(forma.isBlank() ? null : forma); f.setObservaciones(obs.isBlank() ? null : obs);
            srv.crearFactura(f, items);
            JOptionPane.showMessageDialog(this, "Factura creada (#"+f.getId()+")");
            refrescar(); nueva();
        } catch(NumberFormatException ex){ 
            JOptionPane.showMessageDialog(this, "El ID de dueño debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch(Exception ex){ 
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
        }
    }
    private void cambiar(String nuevo){
        int row = tblFact.getSelectedRow(); if (row==-1){ JOptionPane.showMessageDialog(this, "Selecciona una factura."); return; }
        long id = Long.parseLong(String.valueOf(mFact.getValueAt(tblFact.convertRowIndexToModel(row),0)));
        if ("PAGADA".equalsIgnoreCase(nuevo)){
            // Preguntar método de pago
            String[] opciones = new String[]{"EFECTIVO","TARJETA DEBITO","TARJETA CREDITO"};
            String seleccion = (String) JOptionPane.showInputDialog(this, "Seleccione método de pago:", "Pago", JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
            if (seleccion==null) return; // cancel
            try{
                srv.pagarFactura(id, seleccion);
                JOptionPane.showMessageDialog(this, "Factura marcada como PAGADA ("+seleccion+")");
            } catch(Exception ex){ JOptionPane.showMessageDialog(this, "Error al marcar pagada: "+ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
        } else {
            srv.actualizarEstado(id, nuevo);
        }
        refrescar();
    }
    private void calcTotal(){
        double t=0.0;
        for (int i=0;i<mItems.getRowCount();i++){
            int cant=0; double precio=0.0;
            try{ cant=Integer.parseInt(String.valueOf(mItems.getValueAt(i,1))); }catch(Exception ignore){}
            try{ precio=Double.parseDouble(String.valueOf(mItems.getValueAt(i,2))); }catch(Exception ignore){}
            double sub=cant*precio; mItems.setValueAt(sub,i,3); t+=sub;
        }
        lblTotal.setText(String.format("$ %.2f", t));
    }
    private static java.time.LocalDate parse(String s){ return DateUtil.parse(s); }
}
