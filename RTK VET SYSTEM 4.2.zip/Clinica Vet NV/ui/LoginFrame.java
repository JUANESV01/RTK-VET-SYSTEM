
package ui;
import java.awt.*;
import javax.swing.*;
import model.entities.Usuario;
import model.services.IAuthService;
import ui.utils.RTKColors;

@SuppressWarnings("this-escape")
public class LoginFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private transient final IAuthService auth;
    private final JTextField txtEmail = new JTextField(18);
    private final JPasswordField txtPass = new JPasswordField(18);
    public LoginFrame(IAuthService auth){
        super("RTK VET - Login");
        this.auth = auth;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 500); setLocationRelativeTo(null);
    // Use Theme for consistent look and feel (will set white background)
    setLayout(new BorderLayout(0, 20));
        
        // Panel superior con título
        var topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(RTKColors.WHITE);
        topPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        var titleLabel = new JLabel("RTK VET");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 48));
        titleLabel.setForeground(RTKColors.PRIMARY_BLUE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        var subtitleLabel = new JLabel("Sistema de Gestión Veterinaria");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitleLabel.setForeground(RTKColors.DARK_GRAY);
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        topPanel.add(titleLabel, BorderLayout.CENTER);
        topPanel.add(subtitleLabel, BorderLayout.SOUTH);
        
        // Panel inferior con campos de login
        var loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(RTKColors.WHITE);
        loginPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(RTKColors.PRIMARY_BLUE, 2),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));
        var c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.anchor = GridBagConstraints.WEST;
        
        int r = 0;
        c.gridx = 0; c.gridy = r;
        loginPanel.add(new JLabel("Email:"), c);
        c.gridx = 1;
        loginPanel.add(txtEmail, c);
        r++;
        
        c.gridx = 0; c.gridy = r;
        loginPanel.add(new JLabel("Password:"), c);
        c.gridx = 1;
        loginPanel.add(txtPass, c);
        r++;
        
        var btn = new JButton("Entrar");
        style(btn);
        c.gridx = 1; c.gridy = r;
        c.anchor = GridBagConstraints.CENTER;
        loginPanel.add(btn, c);
        
        btn.addActionListener(e -> entrar());
        txtPass.addActionListener(e -> entrar());
        
        add(topPanel, BorderLayout.NORTH);
        add(loginPanel, BorderLayout.CENTER);
        // Apply global theme last
        ui.utils.Theme.applyToFrame(this);
    }
    private void style(JButton b){ b.setBackground(RTKColors.PRIMARY_BLUE); b.setForeground(Color.WHITE); b.setOpaque(true); b.setFocusPainted(false); }
    private void entrar(){
        try {
            Usuario u = auth.login(txtEmail.getText().trim(), new String(txtPass.getPassword()));
            new MainFrame(u, auth).setVisible(true);
            dispose();
        } catch(Exception ex){ JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }
}
